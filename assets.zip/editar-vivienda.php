<?php
session_start();

require_once 'includes/Autoloap.php';

if(!isset($_SESSION['usuario'])){
    header('Location: https://mubrick.com/reportes/');
}

#Agentes
$agentes = new ControllerAgente();
#Ciudades
$ciudades = new ControllerCiudad();
#Sectores
$sectores = new ControllerSector();
#ControllerVivienda
$cInmueble = new ControllerVivienda();
#Obtengo el inmueble con el ID indicado
$i = $cInmueble->obtenerInmueble($_POST['id']);

function opcionesGenerales($datos, $dUser){

    foreach ($datos as $dato) {
      
      if($dato == $dUser){
        echo "<option value='{$dato}' selected='selected'>{$dato}</option>";
      }else{
        echo "<option value='{$dato}'>{$dato}</option>";
      }
      
    }
}

function opcionesObjetos($datos, $dUser){

    foreach ($datos as $dato) {
      
      if($dato->__GET('nombre') == $dUser){
        echo "<option value='{$dato->__GET('nombre')}' selected='selected'>{$dato->__GET('nombre')}</option>";
      }else{
        echo "<option value='{$dato->__GET('nombre')}'>{$dato->__GET('nombre')}</option>";
      }
      
    }
}

function opcionesCiudades($datos, $dUser){

    foreach ($datos as $dato) {
      
      if($dato->__GET('valor') == $dUser){
        echo "<option value='{$dato->__GET('valor')}' selected='selected'>{$dato->__GET('nombre')}</option>";
      }else{
        echo "<option value='{$dato->__GET('valor')}'>{$dato->__GET('nombre')}</option>";
      }
      
    }
}


function opcionesGestion($datos, $dUser){

    $temp='';

    foreach ($datos as $dato) {
      
      //Mostramos los datos de forma legible
      if($dato == 'for-rent'){
        $temp = 'Arriendo';
      }else if($dato == 'for-sale'){
        $temp = 'Venta';
      }else{
        $temp = 'Arriendo y Venta';
      }

      //Mostramos todos los valores y el establecido en la base de datos
      if($dato == $dUser){
        echo "<option value='{$dato}' selected='selected'>{$temp}</option>";
      }else{
        echo "<option value='{$dato}'>{$temp}</option>";
      }
      
    }
}

function opcionesSectores($dUser, $sectores){

    foreach ($sectores->obtenerSectores()  as $ciudad) {

      if($ciudad->__GET('valor') == $dUser){
        echo "<option value='{$ciudad->__GET('valor')}' selected='selected'>{$ciudad->__GET('nombre')}</option>"; 
      }else{
        echo "<option value='{$ciudad->__GET('valor')}'>{$ciudad->__GET('nombre')}</option>"; 
      }

       foreach ($sectores->obtenerSubSectores($ciudad->__GET('id')) as $sector) {
        if($sector->__GET('valor') == $dUser){
          echo "<option value='{$sector->__GET('valor')}' selected='selected'>-- {$sector->__GET('nombre')}</option>"; 
        }else{
          echo "<option value='{$sector->__GET('valor')}'>-- {$sector->__GET('nombre')}</option>"; 
        }
       }
      
    }
}

?>

<!DOCTYPE html>
<html lang="es">
  <head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="https://mubrick.com/wp-content/uploads/2014/11/mubrick.png" type="image/png" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Editar información</title>

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!-- Estilos -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body style="position:relative; padding-top:150px; ">

<div class="alert alert-info alert-exito" role="alert">Datos actualizados</div>
<div class="alert alert-danger alert-error" role="alert">Error</div>


<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
  
      <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse-2" aria-expanded="false">
        <span class="sr-only">Menú</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"><img src="https://mubrick.com/reportes/assets/img/Logo-Mubrick.png" alt="Mubrick"></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse hidden-sm" id="collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
            <img src="https://mubrick.com/reportes/assets/img/user.png" alt="">
            <span class="nombre-usuario">Mubricker<strong>:</strong> <?php echo ucwords($_SESSION['usuario']); ?> <span class="caret" style="color:#fff;"></span></span>
          </a>
          <ul class="dropdown-menu">
            <li><a href="https://mubrick.com/reportes/inmuebles.php">Regresar</a></li>
            <li><a href="https://mubrick.com/reportes/cerrar.php">Salir</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="collapse-2">
      		<ul class="nav navbar-nav navbar-right">
        		<li><a href="https://mubrick.com/reportes/inmuebles.php" style="color:#fff;">Regresar</a></li>
        		<li><a href="https://mubrick.com/reportes/cerrar.php" style="color:#fff;">Salir</a></li>
      		</ul>
    	</div><!-- / .navbar-collapse -->
  	</div><!-- /.container -->
</nav>
    
    <div class="container">
      <div class="col-md-8 col-md-offset-2">
        <h3>INFORMACIÓN PRINCIPAL</h3>
        <p class="sub">Los campos marcados con <span class="obligatorio">*</span> son obligatorios.</p>
        <div class="divisor"></div>
          <form action ="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">

              <!-- id del inmueble -->
              <input type="hidden"  name="id" value="<?php echo $_POST['id']; ?>"> 

              <div class="form-group">
                <label for="ciudad">Ciudad <span class="obligatorio">*</span></label>
                <select class="form-control" id="ciudad" name="ciudad" required>
                  <?php opcionesCiudades($ciudades->obtenerCiudades(), $i->ciudad); ?>
                </select>
              </div>
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="sector">Sector <span class="obligatorio">*</span></label>
                    <select class="form-control" id="sector" name="sector" required>
                      <?php opcionesSectores($i->sector, $sectores); ?>
                    </select>
                  </div>
                </div><!-- .col -->
                <div class="col-md-2">
                  <div class="form-group">
                    <label for="estrato">Estrato <span class="obligatorio">*</span></label>
                    <select class="form-control" id="estrato" name="estrato" required>
                    <?php opcionesGenerales(array("1","2","3","4","5","6"), $i->estrato); ?>
                    </select>
                  </div>
                </div><!-- .col -->
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="barrio">Barrio <span class="obligatorio">*</span></label>
                    <input type="text" value="<?php echo $i->barrio; ?>" class="form-control" id="barrio" placeholder="Barrio" name="barrio" required>
                  </div>
                </div><!-- .col -->
              </div><!-- .row -->
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="tipo">Tipo de Inmueble <span class="obligatorio">*</span></label>
                    <select class="form-control" id="tipo" name="tipo_inmueble" required>
                      <?php opcionesGenerales(array("apartamento","casa","finca"), $i->tipo_inmueble); ?>
                    </select>
                  </div>
                </div><!-- .col -->
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="num-apt">Número de apartamento</label>
                    <input type="text" class="form-control" id="num-apt" placeholder="Número de apartamento" name="numero_apto" value="<?php echo $i->numero_apto; ?>">
                  </div>
                </div><!-- .col -->
              </div><!-- .row -->
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="contrato">Tipo de oferta <span class="obligatorio">*</span></label>
                    <select class="form-control" id="contrato" name="tipo_oferta" required>
                      <?php opcionesGestion(array("for-sale","for-rent","for-rent_and_for-sale"), $i->tipo_oferta); ?>
                    </select>
                  </div>
                </div><!-- .col --> 
                <div class="col-md-6">
                <div class="form-group has-feedback" id="canon">
                  <label class="control-label" for="canon-arrendamiento">Canon de arrendamiento</label>
                  <div class="input-group">
                    <span class="input-group-addon">$</span>
                    <input type="text" class="form-control" id="canon-arrendamiento" placeholder="Canon de arrendamiento" name="canon" value="<?php echo $i->canon; ?>">
                  </div>
                </div>
                </div><!-- .col -->
              </div><!-- .row -->
              <div class="row">        
                <div class="col-md-6">
                  <div class="form-group has-feedback" id="precio_venta">
                    <label class="control-label" for="precio">Precio de venta</label>
                    <div class="input-group">
                      <span class="input-group-addon">$</span>
                      <input type="text" class="form-control" id="precio" placeholder="Precio de lanzamiento" name="precio_lanzamiento" value="<?php echo $i->precio_lanzamiento; ?>">
                    </div>
                  </div>
                </div><!-- .col -->
                <div class="col-md-6">
                  <div class="form-group has-feedback">
                    <label class="control-label" for="costo-admin">Costo de administración</label>
                    <div class="input-group">
                      <span class="input-group-addon">$</span>
                      <input type="text" class="form-control" id="costo-admin" placeholder="Costo de administración" name="costo_admin" value="<?php echo $i->costo_admin; ?>">
                    </div>
                  </div>
                </div><!-- .col -->
              </div><!-- .row -->

                <h3>CARACTERÍSTICAS INTERIORES</h3>
                <div class="divisor"></div>

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="habitaciones">Habitaciones <span class="obligatorio">*</span></label>
                      <input type="text" class="form-control" id="habitaciones" placeholder="Habitaciones" name="habitaciones" value="<?php echo $i->habitaciones; ?>" required>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="baños">Baños <span class="obligatorio">*</span></label>
                      <input type="text" class="form-control" id="banios" placeholder="Baños" name="banios" value="<?php echo $i->banios; ?>" required>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                     <div class="form-group">
                        <label for="parqueaderos">Parqueaderos <span class="obligatorio">*</span></label>
                        <input type="text" class="form-control" id="parqueaderos" placeholder="Parqueaderos" name="parqueaderos" value="<?php echo $i->parqueaderos; ?>" required>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="area-construida">Área construida (m²) <span class="obligatorio">*</span></label>
                      <input type="text" class="form-control" id="area-construida" placeholder="Área construida" name="area_construida" value="<?php echo $i->area_construida; ?>" required>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="area-privada">Área privada (m²)<span class="obligatorio">*</span></label>
                      <input type="text" class="form-control" id="area-privada" placeholder="Área privada" name="area_privada" value="<?php echo $i->area_privada; ?>" required>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                    <label for="balcon_terraza">Balcón - terraza</label>
                      <select class="form-control" id="balcon_terraza" name="balcon_terraza">
                        <?php opcionesGenerales(array("No","Balcón","Terraza","Balcón - terraza"), $i->balcon_terraza); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="area-total">Área total (m²)</label>
                      <input type="text" class="form-control" id="area-total" placeholder="Área lote" name="area_total" value="<?php echo $i->area_total; ?>">
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="area-balcones">Área balcon - terraza (m²)</label>
                      <input type="text" class="form-control" id="area-balcones" placeholder="Área balcón - terraza" name="area_b_t" value="<?php echo $i->area_b_t; ?>">
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="year">Año de construcción <span class="obligatorio">*</span></label>
                      <input type="text" class="form-control" id="year" placeholder="Año" name="anio_construccion" value="<?php echo $i->anio_construccion; ?>">
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="pisos">Piso <span class="obligatorio">*</span></label>
                      <input type="text" class="form-control" id="pisos" placeholder="En que piso está el inmueble" name="pisos" value="<?php echo $i->pisos; ?>" required>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                        <label for="calentador">Tipo de calentador</label>
                        <select class="form-control" id="calentador" name="calentador">
                           <?php opcionesGenerales(array("Gas","Eléctrico","Caldera"), $i->calentador); ?>
                        </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="aire">Aire acondicionado</label>
                      <select class="form-control" id="aire" name="aire_acondicionado">
                         <?php opcionesGenerales(array("No","Si"), $i->aire_acondicionado); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="penthouse">Penthouse</label>
                      <select class="form-control" id="penthouse" name="penthouse">
                        <?php opcionesGenerales(array("No","Si"), $i->penthouse); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                     <label for="duplex">Dúplex</label>
                      <select class="form-control" id="duplex" name="duplex">
                        <?php opcionesGenerales(array("No","Si"), $i->duplex); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="amoblado">Amoblado</label>
                      <select class="form-control" id="amoblado" name="amoblado">
                        <?php opcionesGenerales(array("No","Si"), $i->amoblado); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="tipo-piso">Tipo de piso</label>
                      <select class="form-control" id="tipo-piso" name="tipo_piso">
                        <?php opcionesGenerales(array("Laminado","Cerámica","Baldosa","Madera","Alfombra","Cemento pulido","Porcelanato","Mármol","Varios"), $i->tipo_piso); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="cocina">Cocina abierta o cerrada</label>
                      <select class="form-control" id="cocina" name="cocina_a_c">
                        <?php opcionesGenerales(array("No","Abierta","Cerrada","Semiabierta"), $i->cocina_a_c); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                     <div class="form-group">
                      <label for="tipo-cocina">Tipo de cocina</label>
                      <select class="form-control" id="tipo-cocina" name="tipo_cocina">
                        <?php opcionesGenerales(array("No","Gas","Eléctrica","Mixta"), $i->tipo_cocina); ?>
                      </select>
                     </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="comedor">Comedor independiente</label>
                      <select class="form-control" id="comedor" name="comedor_independiente">
                        <?php opcionesGenerales(array("No","Si"), $i->comedor_independiente); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="vista">Vista exterior o interior</label>
                      <select class="form-control" id="vista" name="vista_e_i">
                        <?php opcionesGenerales(array("Exterior","Interior","Exterior e Interior"), $i->vista_e_i); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="chimenea">Chimenea</label>
                      <select class="form-control" id="chimenea" name="chimenea">
                        <?php opcionesGenerales(array("No","Si"), $i->chimenea); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->
             
                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="cortinas">Cortinas o persianas</label>
                      <select class="form-control" id="cortinas" name="cortinas">
                        <?php opcionesGenerales(array("No","Cortinas en velos","Persianas","Cortinas pesadas"), $i->cortinas); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="servicio">Cuarto de servicio</label>
                      <select class="form-control" id="servicio" name="cuarto_servicio">
                        <?php opcionesGenerales(array("No","Si"), $i->cuarto_servicio); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="estudio">Estudio</label>
                      <select class="form-control" id="estudio" name="estudio">
                        <?php opcionesGenerales(array("No","Si"), $i->estudio); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->
                
                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="seguridad">Puerta de seguridad</label>
                      <select class="form-control" id="seguridad" name="puerta_seguridad">
                        <?php opcionesGenerales(array("No","Si"), $i->puerta_seguridad); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="deposito">Depósito</label>
                      <select class="form-control" id="deposito" name="deposito">
                        <?php opcionesGenerales(array("No","Si"), $i->deposito); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="jacuzzi">Jacuzzi/Sauna</label>
                      <select class="form-control" id="jacuzzi" name="jacuzzi_sauna">
                        <?php opcionesGenerales(array("No","Si"), $i->jacuzzi_sauna); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="parq">Tipo de parqueadero</label>
                      <select class="form-control" id="parq" name="parqueadero_line_inde">
                        <?php opcionesGenerales(array("Independientes","En línea","Servidumbre"), $i->parqueadero_line_inde); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="z-ropa">Zona de ropas</label>
                      <select class="form-control" id="z-ropa" name="zona_ropas">
                        <?php opcionesGenerales(array("No","Si"), $i->zona_ropas); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="remo">Estado del inmueble</label>
                      <select class="form-control" id="remo" name="remodelado">
                        <?php opcionesGenerales(array("Remodelado","No remodelado","Parcialmente","Obra gris"), $i->remodelado); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->
                
                <h3>CARACTERÍSTICAS EXTERIORES</h3>
                <div class="divisor"></div>

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="port">Portería vigilancia</label>
                      <select class="form-control" id="port" name="porteria">
                        <?php opcionesGenerales(array("No","Vigilancia 24/7","Vigilancia 12/7"), $i->porteria); ?>
                      </select>
                     </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="parq-visita">Parqueadero visitantes</label>
                      <select class="form-control" id="parq-visita" name="parqueadero_visita">
                        <?php opcionesGenerales(array("No","Si"), $i->parqueadero_visita); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="zona-infan">Zona infantil</label>
                      <select class="form-control" id="zona-infan" name="zona_infantil">
                        <?php opcionesGenerales(array("No","Si"), $i->zona_infantil); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="ascensor">Ascensor</label>
                      <select class="form-control" id="ascensor" name="ascensor">
                        <?php opcionesGenerales(array("No","Si"), $i->ascensor); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="piscina">Piscina</label>
                      <select class="form-control" id="piscina" name="piscina">
                        <?php opcionesGenerales(array("No","Si"), $i->piscina); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="canchas">Canchas deportivas</label>
                      <select class="form-control" id="canchas" name="canchas_depo">
                        <?php opcionesGenerales(array("No","Si"), $i->canchas_depo); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="gym">Gimnasio</label>
                      <select class="form-control" id="gym" name="gym">
                        <?php opcionesGenerales(array("No","Si"), $i->gym); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="z-humedas">Zonas húmedas</label>
                      <select class="form-control" id="z-humedas" name="zonas_humedas">
                        <?php opcionesGenerales(array("No","Si"), $i->zonas_humedas); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-4"> 
                    <div class="form-group">
                      <label for="t-salon">Terraza y/o salón comunal</label>
                      <select class="form-control" id="t-salon" name="terraza_comunal">
                        <?php opcionesGenerales(array("No","Si"), $i->terraza_comunal); ?>
                      </select>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="form-group">
                  <label for="info_adicional">Información adicional</label>
                  <textarea class="form-control" rows="3" id="info_adicional" name="info_adicional" placeholder="Características sensoriales (Ejem: vista, cálido, iluminado, fresco, espacioso, silencioso, seguro, etc)"><?php echo $i->info_adicional; ?></textarea>
                </div>   

                <h3>CARACTERÍSTICAS DEL PRECIO</h3>
                <div class="divisor"></div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group has-feedback">
                      <label class="control-label" for="avaluo">Avalúo catastral</label>
                      <div class="input-group">
                        <span class="input-group-addon">$</span>
                        <input type="text" class="form-control" id="avaluo" placeholder="Avalúo" name="avaluo_catastral" value="<?php echo $i->avaluo_catastral; ?>">
                      </div>
                    </div>
                </div><!-- .col -->
                 <div class="col-md-6">
                    <div class="form-group has-feedback">
                      <label class="control-label" for="precio-minimo">Precio mínimo</label>
                      <div class="input-group">
                        <span class="input-group-addon">$</span>
                        <input type="text" class="form-control" id="precio-minimo" placeholder="Precio mínimo" name="precio_minimo" value="<?php echo $i->precio_minimo; ?>">
                      </div>
                    </div>

                   
                  </div><!-- .col -->
                </div><!-- .row -->
                
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group has-feedback">
                      <label class="control-label" for="predial">Costo del predial</label>
                      <div class="input-group">
                        <span class="input-group-addon">$</span>
                        <input type="text" class="form-control" id="predial" placeholder="Costo del predial" name="costo_predial" value="<?php echo $i->costo_predial; ?>">
                      </div>
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-6">
                    <div class="form-group has-feedback">
                      <label class="control-label" for="leasing">Valor leasing o hipoteca</label>
                      <div class="input-group">
                        <span class="input-group-addon">$</span>
                        <input type="text" class="form-control" id="leasing" placeholder="Valor leasing o hipoteca" name="valor_leasing" value="<?php echo $i->valor_leasing; ?>">
                      </div>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="form-group">
                  <label for="info-adicional-bancaria">Datos adicionales</label>
                  <textarea class="form-control" rows="3" id="info-adicional-bancaria" name="info_adicional_bancaria" placeholder="Información detallada del Leasing o hipoteca"><?php echo $i->info_adicional_bancaria; ?></textarea>
                </div>    
         
            
                <h3>INFORMACIÓN DEL PROPIETARIO</h3>
                <div class="divisor"></div>
       
                  <div class="form-group">
                    <label for="nombre">Nombres y apellidos <span class="obligatorio">*</span></label>
                    <input type="text" class="form-control" id="nombre" placeholder="Nombre completo" name="nombre" value="<?php echo $i->nombre; ?>" required>
                  </div>
                  
                  <div class="row">
                  <div class="col-md-6">
                   <div class="form-group">
                      <label for="tipo_documento">Tipo documento <span class="obligatorio">*</span></label>
                      <select class="form-control" id="tipo_documento" name="tipo_documento">
                        <?php opcionesGenerales(array("Cédula","Cédula de extranjería","Nit","Pasaporte"), $i->tipo_documento); ?>
                      </select>
                  </div>
                  </div><!-- .col -->

                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="cedula">Número de documento <span class="obligatorio">*</span></label>
                      <input type="text" class="form-control" id="cedula" placeholder="Documento" name="cedula" value="<?php echo $i->cedula; ?>" required>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="direccion-inmueble">Dirección del inmueble <span class="obligatorio">*</span></label>
                      <input type="text" class="form-control" id="direccion-inmueble" placeholder="Dirección" name="direccion" value="<?php echo $i->direccion; ?>" required> 
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="matricula">Matrícula inmobiliaria No</label>
                      <input type="text" class="form-control" id="matricula" placeholder="Matricula" name="matricula_no" value="<?php echo $i->matricula_no; ?>">
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="telefono">Teléfono <span class="obligatorio">*</span></label>
                      <input type="text" class="form-control" id="telefono" placeholder="Teléfono" name="telefono" value="<?php echo $i->telefono; ?>" required> 
                    </div>
                  </div><!-- .col -->
                  <div class="col-md-6">
                     <div class="form-group">
                      <label for="email">Email <span class="obligatorio">*</span></label>
                      <input type="email" class="form-control" id="email" placeholder="Email" name="email" value="<?php echo $i->email; ?>" required>
                    </div>
                  </div><!-- .col -->
                </div><!-- .row -->    

                <h3>AGENTE</h3>
                <p class="sub">Solo para Agentes de Mubrick</p>
                <div class="divisor"></div>

                <div class="form-group">
                  <label for="agente">Agente</label>
                  <select class="form-control" id="agente" name="agente">
                    <?php opcionesObjetos($agentes->obtenerAgentes(), $i->agente); ?>
                  </select>
                </div>

                <div class="botones">
                  <div class="content-btn">
                    <button name="form-inmueble" class="btn btn-default mi-btn" id="boton">Actualizar <i id="spinner" class="fa fa-spinner fa-pulse fa-1x fa-fw" style="display:none;"></i></button>   
                  </div>
                </div>

        </form>
      </div><!-- /.col -->  
    </div><!-- /.container -->  

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Eliminar inmueble -->
    <script src="assets/js/eliminarInmueble.js"></script>
    <!-- Editar inmueble -->
    <script src="assets/js/editar.js"></script>
    <!-- comprobaciones -->
    <script src="assets/js/comprobaciones.js"></script>
    <!-- actualizar datos -->
    <script src="assets/js/actualizar.vivienda.js"></script>
  </body>
</html>