<?php



    class ControllerPropiedades{

        private $pdo;

        public function __CONSTRUCT(){
            try {
                $this->pdo = new PDO('mysql:host=localhost;dbname=roberto_realtorscolombia', 'roberto_realtors', 'kvOGmfRGA&3$');
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
                $this->pdo->exec("set names utf8");


            } catch (Exception $e) {
                die($e->getMessage());
            }
        }

         public function obtenerPropiedades(){
        try
        {
          

            $stm = $this->pdo->prepare
            (htmlspecialchars_decode("

            SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_codigo'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_price'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_ciudad'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_barrio'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_tipo_inmueble'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_status'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_estrato'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_admon'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_bed'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_bath'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_parqueadero_visitantes'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_area_construida'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_area_privada'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_yearbuild'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, d.meta_value  from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where 
p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_floor'

UNION ALL 
SELECT p.ID, p.post_date,d.meta_key, 
(
select post_title from mubrick_posts 
where ID = SUBSTR(d.meta_value, LOCATE('&quot;',d.meta_value)+1, ( CHAR_LENGTH(d.meta_value) - LOCATE('&quot;',REVERSE(d.meta_value)) - LOCATE('&quot;',d.meta_value)))
) as meta_value
from mubrick_posts p 
INNER JOIN mubrick_postmeta d ON p.ID = d.post_id 
where p.post_type = 'listing' 
and p.post_status = 'publish' 
and d.meta_key = 'shandora_listing_agentpointed'

ORDER BY post_date DESC

            "));

            $stm->execute();
            $id;
            $ids = array();
            $cont = 0;
            $result = array();
            $pTemp;

            foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
            {
                $cont++;

                $id = $r->ID;
                $ids[] = $r->ID;

                if($id == $ids[0]){

                    if($cont == 1){
                       $p = new Propiedades(); 
                    }

                    if($r->meta_key == 'shandora_listing_codigo'){
                        $p->__SET('codigo',$r->meta_value);
                        $p->__SET('fecha',$r->post_date);
                    }else if($r->meta_key == 'shandora_listing_price'){
                        $p->__SET('precio',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_ciudad'){
                        $p->__SET('ciudad',ucwords(strtolower($r->meta_value)));
                    }else if($r->meta_key == 'shandora_listing_barrio'){
                        $p->__SET('barrio',ucwords(strtolower($r->meta_value)));
                    }else if($r->meta_key == 'shandora_listing_tipo_inmueble'){
                        $p->__SET('tipo',ucwords(strtolower($r->meta_value)));
                    }else if($r->meta_key == 'shandora_listing_status'){
                        $p->__SET('status',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_estrato'){
                        $p->__SET('estrato',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_admon'){
                        $p->__SET('admin',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_bed'){
                        $p->__SET('bed',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_bath'){
                        $p->__SET('bath',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_parqueadero_visitantes'){
                        $p->__SET('park',ucwords(strtolower($r->meta_value)));
                    }else if($r->meta_key == 'shandora_listing_area_construida'){
                        $p->__SET('area_total',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_area_privada'){
                        $p->__SET('area_privada',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_yearbuild'){
                        $p->__SET('year',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_floor'){
                        $p->__SET('pisos',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_agentpointed'){
                        $p->__SET('autor',ucwords(strtolower($r->meta_value)));
                    }

                    $pTemp = $p;

                }else{


                    $ids = array();
                    $result[] = $p;
                    $p = new Propiedades(); 

                      if($r->meta_key == 'shandora_listing_codigo'){
                        $p->__SET('codigo',$r->meta_value);
                        $p->__SET('fecha',$r->post_date);
                    }else if($r->meta_key == 'shandora_listing_price'){
                        $p->__SET('precio',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_ciudad'){
                        $p->__SET('ciudad',ucwords(strtolower($r->meta_value)));
                    }else if($r->meta_key == 'shandora_listing_barrio'){
                        $p->__SET('barrio',ucwords(strtolower($r->meta_value)));
                    }else if($r->meta_key == 'shandora_listing_tipo_inmueble'){
                        $p->__SET('tipo',ucwords(strtolower($r->meta_value)));
                    }else if($r->meta_key == 'shandora_listing_status'){
                        $p->__SET('status',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_estrato'){
                        $p->__SET('estrato',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_admon'){
                        $p->__SET('admin',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_bed'){
                        $p->__SET('bed',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_bath'){
                        $p->__SET('bath',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_parqueadero_visitantes'){
                        $p->__SET('park',ucwords(strtolower($r->meta_value)));
                    }else if($r->meta_key == 'shandora_listing_area_construida'){
                        $p->__SET('area_total',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_area_privada'){
                        $p->__SET('area_privada',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_yearbuild'){
                        $p->__SET('year',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_floor'){
                        $p->__SET('pisos',$r->meta_value);
                    }else if($r->meta_key == 'shandora_listing_agentpointed'){
                        $p->__SET('autor',ucwords(strtolower($r->meta_value)));
                    }

                }
                
            }

            $result[] = $pTemp;
            return $result;

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    }
?>