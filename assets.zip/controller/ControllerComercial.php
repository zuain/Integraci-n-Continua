<?php

    class ControllerComercial{

        private $pdo;

        public function __CONSTRUCT(){
            try {
                $this->pdo = new PDO('mysql:host=localhost;dbname=roberto_realtorscolombia', 'roberto_realtors', 'kvOGmfRGA&3$');
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
                $this->pdo->exec("set names utf8");


            } catch (Exception $e) {
                die($e->getMessage());
            }
        }

        public function obtenerInmueble($id){
            try {

            $stm = $this->pdo->prepare("select * from pre_consignar_comercial where id=?");
            $stm->bindParam(1,$id);
            $stm->execute();
            $i = new Comercial();  

            if($stm){
             foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {
              $i->__SET('estado',$r->estado );
              $i->__SET('ciudad',$r->ciudad );
              $i->__SET('sector',$r->sector );
              $i->__SET('estrato',$r->estrato );
              $i->__SET('barrio',$r->barrio );
              $i->__SET('tipo_inmueble',$r->tipo_inmueble );
              $i->__SET('tipo_oferta',$r->tipo_oferta );
              $i->__SET('costo_admin',$r->costo_admin );
              $i->__SET('oficinas_privadas',$r->oficinas_privadas );
              $i->__SET('salas_juntas',$r->salas_juntas );
              $i->__SET('mobiliario',$r->mobiliario );
              $i->__SET('banios',$r->banios );
              $i->__SET('parqueaderos',$r->parqueaderos );
              $i->__SET('area_total',$r->area_total );
              $i->__SET('area_b_t',$r->area_b_t );
              $i->__SET('anio_construccion',$r->anio_construccion );
              $i->__SET('pisos', $r->pisos);
              $i->__SET('divisiones', $r->divisiones);
              $i->__SET('cocina', $r->cocina);
              $i->__SET('iluminacion', $r->iluminacion);
              $i->__SET('red', $r->red);
              $i->__SET('tipo_piso', $r->tipo_piso);
              $i->__SET('en_edificio', $r->en_edificio);
              $i->__SET('en_centrocomer', $r->en_centrocomer);
              $i->__SET('en_casa', $r->en_casa);
              $i->__SET('en_calle', $r->en_calle);
              $i->__SET('planta', $r->planta);
              $i->__SET('transporte', $r->transporte);
              $i->__SET('area_abierta', $r->area_abierta);
              $i->__SET('area_oficinas', $r->area_oficinas);
              $i->__SET('puerta_seguridad', $r->puerta_seguridad);
              $i->__SET('deposito', $r->deposito);
              $i->__SET('altura_techo', $r->altura_techo);
              $i->__SET('fondo', $r->fondo);
              $i->__SET('industrial', $r->industrial);
              $i->__SET('p_camiones', $r->p_camiones);
              $i->__SET('porteria', $r->porteria);  
              $i->__SET('entrada_camiones', $r->entrada_camiones);
              $i->__SET('bascula', $r->bascula);
              $i->__SET('ascensor', $r->ascensor);
              $i->__SET('precio_lanzamiento', $r->precio_lanzamiento);
              $i->__SET('nombre', $r->nombre);
              $i->__SET('cedula', $r->cedula);
              $i->__SET('direccion', $r->direccion);
              $i->__SET('matricula_no', $r->matricula_no);
              $i->__SET('telefono', $r->telefono);
              $i->__SET('email', $r->email);
              $i->__SET('agente', $r->agente);
              $i->__SET('id_agente', $r->id_agente);
              $i->__SET('tipo_documento', $r->tipo_documento);
              $i->__SET('canon', $r->canon);
              $i->__SET('balcon_terraza', $r->balcon_terraza);
              $i->__SET('info_adicional', $r->info_adicional);
              $i->__SET('area_privada', $r->area_privada);
              $i->__SET('area_construida', $r->area_construida);
            }   
        }             
            return $i;
    }catch(Exception $e){
            die($e->getMessage());
    }
}

    public function actualizarInmueble($i, $id){
        try {

              $stm = $this->pdo->prepare("update pre_consignar_comercial SET
                estado = ?,
                ciudad = ?,
                sector = ?,
                estrato = ?,
                barrio = ?,
                tipo_inmueble = ?,
                tipo_oferta = ?, 
                costo_admin = ?, 
                oficinas_privadas = ?, 
                salas_juntas = ?, 
                mobiliario = ?, 
                banios = ?,
                parqueaderos = ?,
                area_total = ?, 
                area_b_t = ?, 
                anio_construccion = ?, 
                pisos = ?, 
                divisiones = ?, 
                cocina = ?, 
                iluminacion = ?, 
                red = ?, 
                tipo_piso = ?, 
                en_edificio = ?, 
                en_centrocomer = ?, 
                en_casa = ?,
                en_calle = ?, 
                planta = ?, 
                transporte = ?, 
                area_abierta = ?, 
                area_oficinas = ?,
                puerta_seguridad = ?, 
                deposito = ?, 
                altura_techo = ?, 
                fondo = ?, 
                industrial = ?, 
                p_camiones = ?, 
                porteria = ?,
                entrada_camiones = ?, 
                bascula = ?, 
                ascensor = ?, 
                precio_lanzamiento = ?, 
                nombre = ?, 
                cedula = ?, 
                direccion = ?, 
                matricula_no = ?, 
                telefono = ?, 
                email = ?, 
                agente = ?, 
                id_agente = ?, 
                tipo_documento = ?, 
                canon = ?, 
                balcon_terraza = ?, 
                info_adicional = ?, 
                area_privada = ?, 
                area_construida = ?
                where id = ?");
            $stm->bindParam(1, $i->__GET('estado'));
            $stm->bindParam(2, $i->__GET('ciudad'));
            $stm->bindParam(3, $i->__GET('sector'));
            $stm->bindParam(4, $i->__GET('estrato'));
            $stm->bindParam(5, $i->__GET('barrio'));
            $stm->bindParam(6, $i->__GET('tipo_inmueble'));
            $stm->bindParam(7, $i->__GET('tipo_oferta'));
            $stm->bindParam(8, str_replace(',', '', $i->__GET('costo_admin')));
            $stm->bindParam(9, $i->__GET('oficinas_privadas'));
            $stm->bindParam(10, $i->__GET('salas_juntas'));
            $stm->bindParam(11, $i->__GET('mobiliario'));
            $stm->bindParam(12, $i->__GET('banios'));
            $stm->bindParam(13, $i->__GET('parqueaderos'));
            $stm->bindParam(14, $i->__GET('area_total'));
            $stm->bindParam(15, $i->__GET('area_b_t'));
            $stm->bindParam(16, $i->__GET('anio_construccion'));
            $stm->bindParam(17, $i->__GET('pisos'));
            $stm->bindParam(18, $i->__GET('divisiones'));
            $stm->bindParam(19, $i->__GET('cocina'));
            $stm->bindParam(20, $i->__GET('iluminacion'));
            $stm->bindParam(21, $i->__GET('red'));
            $stm->bindParam(22, $i->__GET('tipo_piso'));
            $stm->bindParam(23, $i->__GET('en_edificio'));
            $stm->bindParam(24, $i->__GET('en_centrocomer'));
            $stm->bindParam(25, $i->__GET('en_casa'));
            $stm->bindParam(26, $i->__GET('en_calle'));
            $stm->bindParam(27, $i->__GET('planta'));
            $stm->bindParam(28, $i->__GET('transporte'));
            $stm->bindParam(29, $i->__GET('area_abierta'));
            $stm->bindParam(30, $i->__GET('area_oficinas'));
            $stm->bindParam(31, $i->__GET('puerta_seguridad'));
            $stm->bindParam(32, $i->__GET('deposito'));
            $stm->bindParam(33, $i->__GET('altura_techo'));
            $stm->bindParam(34, $i->__GET('fondo'));
            $stm->bindParam(35, $i->__GET('industrial'));
            $stm->bindParam(36, $i->__GET('p_camiones'));
            $stm->bindParam(37, $i->__GET('porteria'));  
            $stm->bindParam(38, $i->__GET('entrada_camiones'));
            $stm->bindParam(39, $i->__GET('bascula'));
            $stm->bindParam(40, $i->__GET('ascensor'));
            $stm->bindParam(41, str_replace(',', '', $i->__GET('precio_lanzamiento')));
            $stm->bindParam(42, $i->__GET('nombre'));
            $stm->bindParam(43, $i->__GET('cedula'));
            $stm->bindParam(44, $i->__GET('direccion'));
            $stm->bindParam(45, $i->__GET('matricula_no'));
            $stm->bindParam(46, $i->__GET('telefono'));
            $stm->bindParam(47, $i->__GET('email'));
            $stm->bindParam(48, $i->__GET('agente'));
            $stm->bindParam(49, $i->__GET('id_agente'));
            $stm->bindParam(50, $i->__GET('tipo_documento'));
            $stm->bindParam(51, $i->__GET('canon'));
            $stm->bindParam(52, $i->__GET('balcon_terraza'));
            $stm->bindParam(53, $i->__GET('info_adicional'));
            $stm->bindParam(54, $i->__GET('area_privada'));
            $stm->bindParam(55, $i->__GET('area_construida'));
            $stm->bindParam(56, $id);
            echo $id;

            if($stm->execute()){
                return true;
            }else{
                return false;
            }
            
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }


    public function obtenerInmuebleReporte($id){
            try {

            $stm = $this->pdo->prepare("select * from pre_consignar_comercial where id=?");
            $stm->bindParam(1,$id);
            $stm->execute();
            $i = new Comercial();  

            if($stm){
             foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {
              $i->__SET('codigo', $r->codigo );
              $i->__SET('ciudad','Ciudad: ' . $r->ciudad );
              $i->__SET('sector','Sector: ' .  $r->sector );
              $i->__SET('estrato','Estrato: ' .  $r->estrato );
              $i->__SET('barrio','Barrio: ' .  $r->barrio );
              $i->__SET('tipo_inmueble','Tipo inmueble: ' .  $r->tipo_inmueble );
              $tipo = '';
              if($r->tipo_oferta == 'for-sale'){
                $tipo = 'Venta';
              }else if($r->tipo_oferta == 'for-rent'){
                $tipo = 'Arriendo';
              }else{
                $tipo = 'Arriendo y Venta';
              }
              $i->__SET('tipo_oferta','Tipo oferta: ' .  $tipo);
              $i->__SET('costo_admin','Costo Admin: ' .  $r->costo_admin );
              $i->__SET('oficinas_privadas','Oficinas privadas: ' .  $r->oficinas_privadas );
              $i->__SET('salas_juntas','Salas juntas: ' .  $r->salas_juntas );
              $i->__SET('mobiliario','Cuenta con mobiliario: ' .  $r->mobiliario );
              $i->__SET('banios','Baños: ' .  $r->banios );
              $i->__SET('parqueaderos','Parqueaderos: ' .  $r->parqueaderos );
              $i->__SET('area_total','Área total: ' .  $r->area_total );
              $i->__SET('area_b_t','Área balcón y/o terraza: ' .  $r->area_b_t );
              $i->__SET('anio_construccion', 'Año: ' .  $r->anio_construccion );
              $i->__SET('pisos', 'Piso: ' .  $r->pisos);
              $i->__SET('divisiones','Divisiones: ' .   $r->divisiones);
              $i->__SET('cocina','Cocina: ' .  $r->cocina);
              $i->__SET('iluminacion','Iluminación: ' .  $r->iluminacion);
              $i->__SET('red','Red: ' .  $r->red);
              $i->__SET('tipo_piso','Tipo piso: ' .  $r->tipo_piso);
              $i->__SET('en_edificio','En edificio: ' .  $r->en_edificio);
              $i->__SET('en_centrocomer','En centro comercial: ' .  $r->en_centrocomer);
              $i->__SET('en_casa','En casa: ' .  $r->en_casa);
              $i->__SET('en_calle','En calle: ' .  $r->en_calle);
              $i->__SET('planta','Planta: ' .  $r->planta);
              $i->__SET('transporte','Transporte: ' .  $r->transporte);
              $i->__SET('area_abierta','Área abierta: ' .  $r->area_abierta);
              $i->__SET('area_oficinas', 'Área oficinas: ' .  $r->area_oficinas);
              $i->__SET('puerta_seguridad','Puerta seguridad: ' .  $r->puerta_seguridad);
              $i->__SET('deposito','Deposito: ' .  $r->deposito);
              $i->__SET('altura_techo','Altura techo: ' .  $r->altura_techo);
              $i->__SET('fondo','Fondo: ' .  $r->fondo);
              $i->__SET('industrial','Industrial: ' .  $r->industrial);
              $i->__SET('p_camiones','Portón camiones: ' .  $r->p_camiones);
              $i->__SET('porteria','Portería: ' .  $r->porteria);  
              $i->__SET('entrada_camiones','Entrada camiones: ' .  $r->entrada_camiones);
              $i->__SET('bascula','Báscula: ' .  $r->bascula);
              $i->__SET('ascensor','ascensor: ' .  $r->ascensor);
              $i->__SET('precio_lanzamiento','Precio: ' .  $r->precio_lanzamiento);
              $i->__SET('nombre','Nombre: ' .  $r->nombre);
              $i->__SET('cedula','Documento: ' .  $r->cedula);
              $i->__SET('direccion','Dirección: ' .  $r->direccion);
              $i->__SET('matricula_no','Matrícula No: ' .  $r->matricula_no);
              $i->__SET('telefono','Teléfono: ' .  $r->telefono);
              $i->__SET('email','Email: ' .  $r->email);
              $i->__SET('tipo_documento','Tipo documento: ' .  $r->tipo_documento);
              $i->__SET('canon','Canon arrendamiento: ' .  $r->canon);
              $i->__SET('balcon_terraza','Balcón y/o terraza: ' .  $r->balcon_terraza);
              $i->__SET('area_privada', 'Área privada: ' .  $r->area_privada);
              $i->__SET('area_construida','Área construida: ' .  $r->area_construida);
              $i->__SET('info_adicional',$r->info_adicional);
            }   
        }             
            return $i;
    }catch(Exception $e){
            die($e->getMessage());
    }
}
}
?>