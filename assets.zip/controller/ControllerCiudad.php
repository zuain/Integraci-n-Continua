<?php

    class ControllerCiudad{

        private $pdo;

        public function __CONSTRUCT(){
            try {
                $this->pdo = new PDO('mysql:host=localhost;dbname=roberto_realtorscolombia', 'roberto_realtors', 'kvOGmfRGA&3$');
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
                $this->pdo->exec("set names utf8");


            } catch (Exception $e) {
                die($e->getMessage());
            }
        }

        public function obtenerCiudades(){
            try {

            $stm = $this->pdo->prepare("SELECT u.name as nombre, u.slug as valor FROM mubrick_term_taxonomy tax inner join mubrick_terms u on tax.term_id = u.term_id WHERE tax.taxonomy = 'property-location'and tax.parent = 0");
            $stm->execute();
            $result = array();

            foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {        
                $a = new Ciudad(); 
                $a->__SET('nombre',$r->nombre);
                $a->__SET('valor',$r->valor);
                $result[] = $a;
            }
            return $result;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    }
?>