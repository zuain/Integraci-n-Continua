<?php

    class ControllerFichaHome{

        private $pdo;

        public function __CONSTRUCT(){
            try {
                $this->pdo = new PDO('mysql:host=localhost;dbname=roberto_realtorscolombia', 'roberto_realtors', 'kvOGmfRGA&3$');
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
                $this->pdo->exec("set names utf8");


            } catch (Exception $e) {
                die($e->getMessage());
            }
        }

        public function obtenerViviendas(){
            try {

            $stm = $this->pdo->prepare("select id, nombre, agente, tipo_oferta as gestion from pre_consignar where estado = ?");
            $stm->bindParam(1,$estado='pendiente');
            $stm->execute();
            $result = array();
            $gestion;

            foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {        
                $a = new FichaHome(); 
                $a->__SET('id',$r->id);
                $a->__SET('nombre',$r->nombre);
                $a->__SET('agente',$r->agente);

                switch ($r->gestion) {
                case 'for-sale':
                    $gestion = 'Venta';
                    break;
                case 'for-rent':
                    $gestion = 'Arriendo';
                    break;
                case 'for-rent_and_for-sale':
                    $gestion = 'Arriendo y Venta';
                    break;
            }
                $a->__SET('gestion',$gestion);
                $result[] = $a;
            }
            return $result;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function obtenerComercial(){
            try {

            $stm = $this->pdo->prepare("select id, nombre, agente, tipo_oferta as gestion from pre_consignar_comercial where estado = ? ");
            $stm->bindParam(1,$estado='pendiente');
            $stm->execute();
            $result = array();
            $gestion;

            foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {        
                $a = new FichaHome(); 
                $a->__SET('id',$r->id);
                $a->__SET('nombre',$r->nombre);
                $a->__SET('agente',$r->agente);

                switch ($r->gestion) {
                case 'for-sale':
                    $gestion = 'Venta';
                    break;
                case 'for-rent':
                    $gestion = 'Arriendo';
                    break;
                case 'for-rent_and_for-sale':
                    $gestion = 'Arriendo y Venta';
                    break;
            }
                $a->__SET('gestion',$gestion);
                $result[] = $a;
            }
            return $result;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function eliminar($id, $inmueble){
            try {

            if($inmueble == 'vivienda'){
                $stm = $this->pdo->prepare("delete from pre_consignar WHERE id = ?");
            }else{
                $stm = $this->pdo->prepare("delete from pre_consignar_comercial WHERE id = ?");
            }
            
            $stm->bindParam(1,$id);
        
            return $stm->execute();
        }
        
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    }
?>