<?php

    class ControllerVivienda{

        private $pdo;

        public function __CONSTRUCT(){
                    
                    try {
                        $this->pdo = new PDO('mysql:host=localhost;dbname=roberto_realtorscolombia', 'roberto_realtors', 'kvOGmfRGA&3$');
                        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
                        $this->pdo->exec("set names utf8");


                    } catch (Exception $e) {
                        die($e->getMessage());
                    }
        }


        public function obtenerInmueble($id){
                    
                    try {

                        $stm = $this->pdo->prepare("select * from pre_consignar where id=?");
                        $stm->bindParam(1,$id);
                        $stm->execute();
                        $i = new Vivienda();  

                        if($stm){
                         foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {
                             $i->__SET('estado',$r->estado);
                             $i->__SET('ciudad',$r->ciudad);
                             $i->__SET('sector',$r->sector);
                             $i->__SET('estrato',$r->estrato);
                             $i->__SET('barrio',$r->barrio);
                             $i->__SET('tipo_inmueble',$r->tipo_inmueble);
                             $i->__SET('numero_apto',$r->numero_apto);
                             $i->__SET('tipo_oferta',$r->tipo_oferta);
                             $i->__SET('precio_lanzamiento',$r->precio_lanzamiento);
                             $i->__SET('costo_admin',$r->costo_admin);
                             $i->__SET('habitaciones',$r->habitaciones);
                             $i->__SET('banios',$r->banios);
                             $i->__SET('parqueaderos',$r->parqueaderos);
                             $i->__SET('area_total',$r->area_total);
                             $i->__SET('area_b_t',$r->area_b_t);
                             $i->__SET('anio_construccion',$r->anio_construccion);
                             $i->__SET('pisos',$r->pisos);
                             $i->__SET('penthouse',$r->penthouse);
                             $i->__SET('duplex',$r->duplex);
                             $i->__SET('amoblado',$r->amoblado);
                             $i->__SET('aire_acondicionado',$r->aire_acondicionado);
                             $i->__SET('tipo_piso',$r->tipo_piso);
                             $i->__SET('cocina_a_c',$r->cocina_a_c);
                             $i->__SET('tipo_cocina',$r->tipo_cocina);
                             $i->__SET('comedor_independiente',$r->comedor_independiente);
                             $i->__SET('vista_e_i',$r->vista_e_i);
                             $i->__SET('chimenea',$r->chimenea);
                             $i->__SET('cortinas',$r->cortinas);
                             $i->__SET('cuarto_servicio',$r->cuarto_servicio);
                             $i->__SET('estudio',$r->estudio);
                             $i->__SET('puerta_seguridad',$r->puerta_seguridad);
                             $i->__SET('deposito',$r->deposito);
                             $i->__SET('jacuzzi_sauna',$r->jacuzzi_sauna);
                             $i->__SET('parqueadero_line_inde',$r->parqueadero_line_inde);
                             $i->__SET('zona_ropas',$r->zona_ropas);
                             $i->__SET('remodelado',$r->remodelado);
                             $i->__SET('porteria',$r->porteria);
                             $i->__SET('parqueadero_visita', $r->parqueadero_visita);
                             $i->__SET('zona_infantil',$r->zona_infantil);
                             $i->__SET('ascensor',$r->ascensor);
                             $i->__SET('piscina',$r->piscina);
                             $i->__SET('canchas_depo',$r->canchas_depo);
                             $i->__SET('gym',$r->gym);
                             $i->__SET('zonas_humedas',$r->zonas_humedas);
                             $i->__SET('terraza_comunal',$r->terraza_comunal);
                             $i->__SET('precio_minimo',$r->precio_minimo);
                             $i->__SET('avaluo_catastral',$r->avaluo_catastral);
                             $i->__SET('costo_predial',$r->costo_predial);
                             $i->__SET('valor_leasing',$r->valor_leasing);
                             $i->__SET('nombre',$r->nombre);
                             $i->__SET('cedula',$r->cedula);
                             $i->__SET('direccion',$r->direccion);
                             $i->__SET('matricula_no',$r->matricula_no);
                             $i->__SET('telefono',$r->telefono);
                             $i->__SET('email',$r->email);
                             $i->__SET('agente',$r->agente);
                             $i->__SET('id_agente',$r->id_agente);
                             $i->__SET('tipo_documento',$r->tipo_documento);
                             $i->__SET('calentador',$r->calentador);
                             $i->__SET('canon',$r->canon);
                             $i->__SET('balcon_terraza',$r->balcon_terraza);
                             $i->__SET('info_adicional',$r->info_adicional);
                             $i->__SET('area_privada',$r->area_privada);
                             $i->__SET('area_construida',$r->area_construida);
                             $i->__SET('info_adicional_bancaria',$r->info_adicional_bancaria);
                        }   
                    }             
                        return $i;
                    }catch(Exception $e){
                            die($e->getMessage());
                    }
        }

        public function actualizarInmueble($i, $id){
                try {

                      $stm = $this->pdo->prepare("UPDATE pre_consignar SET
                        estado = ?,
                        ciudad = ?,
                        sector = ?,
                        estrato = ?,
                        barrio = ?,
                        tipo_inmueble = ?,
                        numero_apto = ?,
                        tipo_oferta = ?, 
                        precio_lanzamiento = ?, 
                        costo_admin = ?, 
                        habitaciones = ?, 
                        banios = ?, 
                        parqueaderos = ?, 
                        area_total = ?, 
                        area_b_t = ?, 
                        anio_construccion = ?, 
                        pisos = ?, 
                        penthouse = ?, 
                        duplex = ?, 
                        amoblado = ?, 
                        aire_acondicionado = ?, 
                        tipo_piso = ?, 
                        cocina_a_c = ?, 
                        tipo_cocina = ?, 
                        comedor_independiente = ?,
                        vista_e_i = ?, 
                        chimenea = ?, 
                        cortinas = ?, 
                        cuarto_servicio = ?, 
                        estudio = ?, 
                        puerta_seguridad = ?, 
                        deposito = ?, 
                        jacuzzi_sauna = ?, 
                        parqueadero_line_inde = ?, 
                        zona_ropas = ?, 
                        remodelado = ?, 
                        porteria = ?,
                        parqueadero_visita = ?, 
                        zona_infantil = ?, 
                        ascensor = ?, 
                        piscina = ?, 
                        canchas_depo = ?, 
                        gym = ?, 
                        zonas_humedas = ?, 
                        terraza_comunal = ?, 
                        precio_minimo = ?, 
                        avaluo_catastral = ?,
                        costo_predial = ?, 
                        valor_leasing = ?, 
                        nombre = ?, 
                        cedula = ?, 
                        direccion = ?, 
                        matricula_no = ?, 
                        telefono = ?, 
                        email = ?, 
                        agente = ?, 
                        id_agente = ?,
                        tipo_documento = ?,
                        calentador = ?,
                        canon = ?,
                        balcon_terraza = ?,
                        info_adicional = ?,
                        area_privada = ?,
                        area_construida = ?,
                        info_adicional_bancaria = ?  where id = ?");
                    $stm->bindParam(1, $i->__GET('estado'));
                    $stm->bindParam(2, $i->__GET('ciudad'));
                    $stm->bindParam(3, $i->__GET('sector'));
                    $stm->bindParam(4, $i->__GET('estrato'));
                    $stm->bindParam(5, $i->__GET('barrio'));
                    $stm->bindParam(6, $i->__GET('tipo_inmueble'));
                    $stm->bindParam(7, $i->__GET('numero_apto'));
                    $stm->bindParam(8, $i->__GET('tipo_oferta'));
                    $stm->bindParam(9, str_replace(',', '', $i->__GET('precio_lanzamiento')));
                    $stm->bindParam(10, str_replace(',', '', $i->__GET('costo_admin')));
                    $stm->bindParam(11, $i->__GET('habitaciones'));
                    $stm->bindParam(12, $i->__GET('banios'));
                    $stm->bindParam(13, $i->__GET('parqueaderos'));
                    $stm->bindParam(14, $i->__GET('area_total'));
                    $stm->bindParam(15, $i->__GET('area_b_t'));
                    $stm->bindParam(16, $i->__GET('anio_construccion'));
                    $stm->bindParam(17, $i->__GET('pisos'));
                    $stm->bindParam(18, $i->__GET('penthouse'));
                    $stm->bindParam(19, $i->__GET('duplex'));
                    $stm->bindParam(20, $i->__GET('amoblado'));
                    $stm->bindParam(21, $i->__GET('aire_acondicionado'));
                    $stm->bindParam(22, $i->__GET('tipo_piso'));
                    $stm->bindParam(23, $i->__GET('cocina_a_c'));
                    $stm->bindParam(24, $i->__GET('tipo_cocina'));
                    $stm->bindParam(25, $i->__GET('comedor_independiente'));
                    $stm->bindParam(26, $i->__GET('vista_e_i'));
                    $stm->bindParam(27, $i->__GET('chimenea'));
                    $stm->bindParam(28, $i->__GET('cortinas'));
                    $stm->bindParam(29, $i->__GET('cuarto_servicio'));
                    $stm->bindParam(30, $i->__GET('estudio'));
                    $stm->bindParam(31, $i->__GET('puerta_seguridad'));
                    $stm->bindParam(32, $i->__GET('deposito'));
                    $stm->bindParam(33, $i->__GET('jacuzzi_sauna'));
                    $stm->bindParam(34, $i->__GET('parqueadero_line_inde'));
                    $stm->bindParam(35, $i->__GET('zona_ropas'));
                    $stm->bindParam(36, $i->__GET('remodelado'));
                    $stm->bindParam(37, $i->__GET('porteria'));
                    $stm->bindParam(38, $i->__GET('parqueadero_visita'));  
                    $stm->bindParam(39, $i->__GET('zona_infantil'));
                    $stm->bindParam(40, $i->__GET('ascensor'));
                    $stm->bindParam(41, $i->__GET('piscina'));
                    $stm->bindParam(42, $i->__GET('canchas_depo'));
                    $stm->bindParam(43, $i->__GET('gym'));
                    $stm->bindParam(44, $i->__GET('zonas_humedas'));
                    $stm->bindParam(45, $i->__GET('terraza_comunal'));
                    $stm->bindParam(46, $i->__GET('precio_minimo'));
                    $stm->bindParam(47, $i->__GET('avaluo_catastral'));
                    $stm->bindParam(48, $i->__GET('costo_predial'));
                    $stm->bindParam(49, $i->__GET('valor_leasing'));
                    $stm->bindParam(50, $i->__GET('nombre'));
                    $stm->bindParam(51, $i->__GET('cedula'));
                    $stm->bindParam(52, $i->__GET('direccion'));
                    $stm->bindParam(53, $i->__GET('matricula_no'));
                    $stm->bindParam(54, $i->__GET('telefono'));
                    $stm->bindParam(55, $i->__GET('email'));
                    $stm->bindParam(56, $i->__GET('agente'));
                    $stm->bindParam(57, $i->__GET('id_agente'));
                    $stm->bindParam(58, $i->__GET('tipo_documento'));
                    $stm->bindParam(59, $i->__GET('calentador'));
                    $stm->bindParam(60, $i->__GET('canon'));
                    $stm->bindParam(61, $i->__GET('balcon_terraza'));
                    $stm->bindParam(62, $i->__GET('info_adicional'));
                    $stm->bindParam(63, $i->__GET('area_privada'));
                    $stm->bindParam(64, $i->__GET('area_construida'));
                    $stm->bindParam(65, $i->__GET('info_adicional_bancaria'));
                    $stm->bindParam(66, $id);

                    if($stm->execute()){
                        return true;
                    }else{
                        return false;
                    }
                    
                } catch (Exception $e) {
                    die($e->getMessage());
                }
        }

        public function obtenerInmuebleReporte($id){
                    
                    try {

                        $stm = $this->pdo->prepare("select * from pre_consignar where id=?");
                        $stm->bindParam(1,$id);
                        $stm->execute();
                        $i = new Vivienda();  

                        if($stm){
                         foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {
                             $i->__SET('codigo',$r->codigo);
                             $i->__SET('ciudad','Ciudad: ' . $r->ciudad);
                             $i->__SET('sector','Sector: ' . $r->sector);
                             $i->__SET('estrato','Estrato: ' . $r->estrato);
                             $i->__SET('barrio','Barrio: ' . $r->barrio);
                             $i->__SET('tipo_inmueble','Tipo inmueble: ' . $r->tipo_inmueble);
                             $i->__SET('numero_apto','Numero: ' . $r->numero_apto);
                             $tipo = '';
                             if($r->tipo_oferta == 'for-sale'){
                                $tipo = 'Venta';
                             }else if($r->tipo_oferta == 'for-rent'){
                                $tipo = 'Arriendo';
                             }else{
                                $tipo = 'Arriendo y Venta';
                             }
                             $i->__SET('tipo_oferta','Tipo oferta: ' . $tipo );
                             $i->__SET('precio_lanzamiento','Precio: ' . $r->precio_lanzamiento);
                             $i->__SET('costo_admin','Costo Admin: ' . $r->costo_admin);
                             $i->__SET('habitaciones','Habitaciones: ' . $r->habitaciones);
                             $i->__SET('banios','Baños: ' . $r->banios);
                             $i->__SET('parqueaderos','Parqueaderos: ' . $r->parqueaderos);
                             $i->__SET('area_total','Área total: ' . $r->area_total);
                             $i->__SET('area_b_t','Área balcón y/o terraza: ' . $r->area_b_t);
                             $i->__SET('anio_construccion','Año: ' . $r->anio_construccion);
                             $i->__SET('pisos','Piso: ' . $r->pisos);
                             $i->__SET('penthouse','Penthouse: ' . $r->penthouse);
                             $i->__SET('duplex','Duplex: ' . $r->duplex);
                             $i->__SET('amoblado','Amoblado: ' . $r->amoblado);
                             $i->__SET('aire_acondicionado','Aire acondicionado: ' . $r->aire_acondicionado);
                             $i->__SET('tipo_piso','Tipo piso: ' . $r->tipo_piso);
                             $i->__SET('cocina_a_c','Cocina abierta o cerrada: ' . $r->cocina_a_c);
                             $i->__SET('tipo_cocina','Tipo de cocina: ' . $r->tipo_cocina);
                             $i->__SET('comedor_independiente','Comedor independiente: ' . $r->comedor_independiente);
                             $i->__SET('vista_e_i','Vista exterior o interior: ' . $r->vista_e_i);
                             $i->__SET('chimenea','Chimenea: ' . $r->chimenea);
                             $i->__SET('cortinas','Cortinas: ' . $r->cortinas);
                             $i->__SET('cuarto_servicio','Cuarto de servicio: ' . $r->cuarto_servicio);
                             $i->__SET('estudio','Estudio: ' . $r->estudio);
                             $i->__SET('puerta_seguridad','Puerta de seguridad: ' . $r->puerta_seguridad);
                             $i->__SET('deposito','Depósito: ' . $r->deposito);
                             $i->__SET('jacuzzi_sauna','Jacuzzi: ' . $r->jacuzzi_sauna);
                             $i->__SET('parqueadero_line_inde','Tipo parqueadero: ' . $r->parqueadero_line_inde);
                             $i->__SET('zona_ropas','Zona de ropas: ' . $r->zona_ropas);
                             $i->__SET('remodelado','Estado: ' . $r->remodelado);
                             $i->__SET('porteria','Portería: ' . $r->porteria);
                             $i->__SET('parqueadero_visita','Parqueadero visitas: ' .  $r->parqueadero_visita);
                             $i->__SET('zona_infantil','Zona infantil: ' . $r->zona_infantil);
                             $i->__SET('ascensor','Ascensor: ' . $r->ascensor);
                             $i->__SET('piscina','Piscina: ' . $r->piscina);
                             $i->__SET('canchas_depo','Canchas deportivas: ' . $r->canchas_depo);
                             $i->__SET('gym','Gym: ' . $r->gym);
                             $i->__SET('zonas_humedas','Zonas humedas: ' . $r->zonas_humedas);
                             $i->__SET('terraza_comunal','Terraza comunal: ' . $r->terraza_comunal);
                             $i->__SET('precio_minimo','Precio mínimo: ' . $r->precio_minimo);
                             $i->__SET('avaluo_catastral','Avaluo catastral: ' . $r->avaluo_catastral);
                             $i->__SET('costo_predial','Costo predial: ' . $r->costo_predial);
                             $i->__SET('valor_leasing','Valor leasing: ' . $r->valor_leasing);
                             $i->__SET('nombre','Nombre: ' . $r->nombre);
                             $i->__SET('cedula','Documento: ' . $r->cedula);
                             $i->__SET('direccion','Dirección: ' . $r->direccion);
                             $i->__SET('matricula_no','Matrícula No: ' . $r->matricula_no);
                             $i->__SET('telefono','Teléfono: ' . $r->telefono);
                             $i->__SET('email','Email: ' . $r->email);
                             $i->__SET('tipo_documento','Tipo documento: ' . $r->tipo_documento);
                             $i->__SET('calentador','Ciudad: ' . $r->calentador);
                             $i->__SET('canon','Canon de arrendamiento: ' . $r->canon);
                             $i->__SET('balcon_terraza','Balcón y/o terraza: ' . $r->balcon_terraza);
                             $i->__SET('area_privada','Área privada: ' . $r->area_privada);
                             $i->__SET('area_construida','Área construída: ' . $r->area_construida);
                             $i->__SET('info_adicional','Características: ' . $r->info_adicional);
                             $i->__SET('info_adicional_bancaria','Leasing o hipoteca: ' . $r->info_adicional_bancaria);
                        }   
                    }             
                        return $i;
                    }catch(Exception $e){
                            die($e->getMessage());
                    }
        }

}

?>