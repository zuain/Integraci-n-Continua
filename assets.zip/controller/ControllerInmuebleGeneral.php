<?php



    class ControllerInmuebleGeneral{

         private $pdo;

        public function __CONSTRUCT(){
            try {
                $this->pdo = new PDO('mysql:host=localhost;dbname=roberto_realtorscolombia', 'roberto_realtors', 'kvOGmfRGA&3$');
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
                $this->pdo->exec("set names utf8");


            } catch (Exception $e) {
                die($e->getMessage());
            }
        }

        public function obtenerInmueble($id, $tipo){
            try {

            $stm='';

            if($tipo == 'comercial'){
                $stm = $this->pdo->prepare("select * from pre_consignar_comercial where id = ?");
            }else{
                $stm = $this->pdo->prepare("select * from pre_consignar where id = ?");
            }
            
            $stm->bindParam(1,$id);
            $stm->execute();
            $a = new InmuebleGeneral(); 

            foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {

                $agent = 'a:1:{i:0;s:'.strlen($r->id_agente).':"'.$r->id_agente.'";}';

                $a->__SET('shandora_listing_codigo',$r->codigo );
                $a->__SET('shandora_listing_ciudad',$r->ciudad );
                $a->__SET('shandora_listing_sector',$r->sector );
                $a->__SET('shandora_listing_barrio',$r->barrio );
                $a->__SET('shandora_listing_estrato',$r->estrato );
                $a->__SET('shandora_listing_tipo_inmueble',$r->tipo_inmueble );
                $a->__SET('shandora_listing_status',$r->tipo_oferta );
                $a->__SET('shandora_listing_price',str_replace(',','',$r->precio_lanzamiento ));
                $a->__SET('shandora_listing_admon',str_replace(',','',$r->costo_admin));
                $a->__SET('shandora_listing_bed',$r->habitaciones );
                $a->__SET('shandora_listing_bath',$r->banios );
                $a->__SET('shandora_listing_garage',$r->parqueaderos);
                $a->__SET('shandora_listing_area_construida',$r->area_total );
                $a->__SET('shandora_listing_area_privada',$r->area_privada );
                $a->__SET('shandora_listing_area_b_t',$r->area_b_t );
                $a->__SET('shandora_listing_area_cons_org',$r->area_construida );
                $a->__SET('shandora_listing_floor',$r->pisos );
                $a->__SET('shandora_listing_pent_house',$r->penthouse );
                $a->__SET('shandora_listing_aire_acondicionado',$r->aire_acondicionado );
                $a->__SET('shandora_listing_duplex',$r->duplex );
                $a->__SET('shandora_listing_amoblado',$r->amoblado );
                $a->__SET('shandora_listing_baldosa',$r->tipo_piso );
                $a->__SET('shandora_listing_tipo_cocina',$r->cocina_a_c );
                $a->__SET('shandora_listing_tipo_cocina_1',$r->tipo_cocina );
                $a->__SET('shandora_listing_comedor_independiente',$r->comedor_independiente );
                $a->__SET('shandora_listing_exterior_interior',$r->vista_e_i );
                $a->__SET('shandora_listing_chimenea', $r->chimenea );
                $a->__SET('shandora_listing_cortinas', $r->cortinas );
                $a->__SET('shandora_listing_cuarto_servicio', $r->cuarto_servicio );
                $a->__SET('shandora_listing_estudio', $r->estudio );
                $a->__SET('shandora_listing_puerta_seguridad', $r->puerta_seguridad );
                $a->__SET('shandora_listing_deposito', $r->deposito );
                $a->__SET('shandora_listing_jacuzzi', $r->jacuzzi_sauna );
                $a->__SET('shandora_listing_tipo_garage', $r->parqueadero_line_inde );
                $a->__SET('shandora_listing_zona_lavandería', $r->zona_ropas );
                $a->__SET('shandora_listing_portería', $r->porteria );
                $a->__SET('shandora_listing_parqueadero_visitantes', $r->parqueadero_visita );
                $a->__SET('shandora_listing_zona_infantil', $r->zona_infantil );
                $a->__SET('shandora_listing_ascensor', $r->ascensor );
                $a->__SET('shandora_listing_piscina', $r->piscina );
                $a->__SET('shandora_listing_canchas_deportivas', $r->canchas_depo );
                $a->__SET('shandora_listing_gimnasio', $r->gym );
                $a->__SET('shandora_listing_zonas_humedas', $r->zonas_humedas );
                $a->__SET('shandora_listing_terraza', $r->balcon_terraza );
                $a->__SET('shandora_listing_precio_negociable', $r->precio_minimo ? 'Si' : 'No' );
                $a->__SET('shandora_listing_agentpointed', $agent);                
                $a->__SET('shandora_listing_yearbuild', $r->anio_construccion );
            }

            return $a;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }



     public function agregarCodigo($id, $tipo, $codigo){

        try {

            $stm = '';

            if($tipo == 'comercial'){
                $stm = $this->pdo->prepare("update pre_consignar_comercial set codigo = ? where id = ?");
            }else{
                $stm = $this->pdo->prepare("update pre_consignar set codigo = ? where id = ?");
            }

            $stm->bindParam(1,$codigo);
            $stm->bindParam(2,$id);

            if($stm->execute()){
                return true;
            }
        }
        catch(Exception $e){
            die($e->getMessage());
        }
    }


     public function cambiarEstado($id, $tipo){

        try {

            $stm = '';
            $tempEstado = $estado = 'completo';

            if($tipo == 'comercial'){
                $stm = $this->pdo->prepare("update pre_consignar_comercial set estado = ? where id = ?");
            }else{
                $stm = $this->pdo->prepare("update pre_consignar set estado = ? where id = ?");
            }

            $stm->bindParam(1,$tempEstado);
            $stm->bindParam(2,$id);
            if($stm->execute()){
                return true;
            }
        }
        catch(Exception $e){
            die($e->getMessage());
        }
    }

    public function insertarPost($codigo){

        $date = new DateTime();

        try {
        
           $autor = 2;
           $tempDate = $date->format('Y-m-d H:i:s');
           $tempStatus = $status = 'draft';
           $tempType = $type = 'listing';
           
           $stm = $this->pdo->prepare("insert into mubrick_posts (post_author,post_date,post_title,post_status, post_type) values(?,?,?,?,?)");
           $stm->bindParam(1, $autor);
           $stm->bindParam(2, $tempDate);
           $stm->bindParam(3, $codigo);
           $stm->bindParam(4, $tempStatus);
           $stm->bindParam(5, $tempType);
           $stm->execute();

        }
        catch(Exception $e){
            die($e->getMessage());
        }
    }


    public function obtenerId(){

        try {
           $stm = $this->pdo->prepare("SELECT id FROM mubrick_posts order by post_date DESC limit 1");
           $stm->execute();
           $id='';

           foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {
             $id = $r->id;
           }
           return $id;

        }
        catch(Exception $e){
            die($e->getMessage());
        }
    }

    public function insertarMetaDatos($inmueble, $id){
          
          try {

            $values = array(
             "shandora_listing_codigo",
             "shandora_listing_ciudad",
             "shandora_listing_sector",
             "shandora_listing_barrio",
             "shandora_listing_estrato",
             "shandora_listing_tipo_inmueble",
             "shandora_listing_status",
             "shandora_listing_price",
             "shandora_listing_admon",
             "shandora_listing_bed",
             "shandora_listing_bath",
             "shandora_listing_garage",
             "shandora_listing_area_construida",
             "shandora_listing_area_privada",
             "shandora_listing_area_b_t",
             "shandora_listing_area_cons_org",
             "shandora_listing_floor",
             "shandora_listing_pent_house",
             "shandora_listing_aire_acondicionado",
             "shandora_listing_duplex",
             "shandora_listing_amoblado",
             "shandora_listing_baldosa",
             "shandora_listing_tipo_cocina",
             "shandora_listing_tipo_cocina_1",
             "shandora_listing_comedor_independiente",
             "shandora_listing_exterior_interior",
             "shandora_listing_chimenea",
             "shandora_listing_cortinas",
             "shandora_listing_cuarto_servicio",
             "shandora_listing_estudio",
             "shandora_listing_puerta_seguridad",
             "shandora_listing_deposito",
             "shandora_listing_jacuzzi",
             "shandora_listing_tipo_garage",
             "shandora_listing_zona_lavandería",
             "shandora_listing_portería",
             "shandora_listing_parqueadero_visitantes",
             "shandora_listing_zona_infantil",
             "shandora_listing_ascensor",
             "shandora_listing_piscina",
             "shandora_listing_canchas_deportivas",
             "shandora_listing_gimnasio",
             "shandora_listing_zonas_humedas",
             "shandora_listing_terraza",
             "shandora_listing_precio_negociable",
             "shandora_listing_agentpointed",
             "shandora_listing_yearbuild");
          
           // begin the transaction
            $this->pdo->beginTransaction();

            $stm = $this->pdo->prepare("insert into mubrick_postmeta (post_id, meta_key, meta_value) values (?,?,?)");
            
            
           foreach ($values as $valor) {
           
               $temp = $inmueble->__GET($valor) ? $inmueble->__GET($valor) : '';
               
               $stm->bindParam(1,$id);
               $stm->bindParam(2,$valor);
               $stm->bindParam(3,$temp);
               $stm->execute();
               
           }

            // commit the transaction
            $this->pdo->commit();
        }
        catch(Exception $e){
            $this->pdo->rollback();
            die($e->getMessage());
        }
    }


    }
?>