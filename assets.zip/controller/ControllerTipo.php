<?php

    class ControllerTipo{

        private $pdo;

        public function __CONSTRUCT(){
            try {
                $this->pdo = new PDO('mysql:host=localhost;dbname=roberto_realtorscolombia', 'roberto_realtors', 'kvOGmfRGA&3$');
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
                $this->pdo->exec("set names utf8");


            } catch (Exception $e) {
                die($e->getMessage());
            }
        }

        public function obtenerTipos(){
            try {

            $stm = $this->pdo->prepare("SELECT term.name as nombre FROM mubrick_term_taxonomy taxo INNER JOIN mubrick_terms term on taxo.term_id = term.term_id WHERE taxonomy = 'property-type'");
            $stm->execute();
            $result = array();

            foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {        
                $a = new Tipo(); 
                $a->__SET('nombre',$r->nombre);
                $result[] = $a;
            }
            return $result;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    }
?>