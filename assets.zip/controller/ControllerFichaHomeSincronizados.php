<?php

    class ControllerFichaHomeSincronizados{

        private $pdo;

        public function __CONSTRUCT(){
            try {
                $this->pdo = new PDO('mysql:host=localhost;dbname=roberto_realtorscolombia', 'roberto_realtors', 'kvOGmfRGA&3$');
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
                $this->pdo->exec("set names utf8");


            } catch (Exception $e) {
                die($e->getMessage());
            }
        }

        public function obtenerViviendas(){
            try {

            $stm = $this->pdo->prepare("select id, nombre, agente, tipo_oferta as gestion, codigo from pre_consignar where estado = ? order by codigo ASC");
            $stm->bindParam(1,$estado='completo');
            $stm->execute();
            $result = array();
            $gestion;

            foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {        
                $a = new FichaHome(); 
                $a->__SET('id',$r->id);
                $a->__SET('nombre',$r->nombre);
                $a->__SET('agente',$r->agente);
                $a->__SET('codigo',$r->codigo);

                switch ($r->gestion) {
                case 'for-sale':
                    $gestion = 'Venta';
                    break;
                case 'for-rent':
                    $gestion = 'Arriendo';
                    break;
                case 'for-rent_and_for-sale':
                    $gestion = 'Arriendo y Venta';
                    break;
            }
                $a->__SET('gestion',$gestion);
                $result[] = $a;
            }
            return $result;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function obtenerComercial(){
            try {

            $stm = $this->pdo->prepare("select id, nombre, agente, tipo_oferta as gestion, codigo from pre_consignar_comercial where estado = ? order by codigo ASC");
            $stm->bindParam(1,$estado='completo');
            $stm->execute();
            $result = array();
            $gestion;

            foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {        
                $a = new FichaHome(); 
                $a->__SET('id',$r->id);
                $a->__SET('nombre',$r->nombre);
                $a->__SET('agente',$r->agente);
                $a->__SET('codigo',$r->codigo);

                switch ($r->gestion) {
                case 'for-sale':
                    $gestion = 'Venta';
                    break;
                case 'for-rent':
                    $gestion = 'Arriendo';
                    break;
                case 'for-rent_and_for-sale':
                    $gestion = 'Arriendo y Venta';
                    break;
            }
                $a->__SET('gestion',$gestion);
                $result[] = $a;
            }
            return $result;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    }
?>