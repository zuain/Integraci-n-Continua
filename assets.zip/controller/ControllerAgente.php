<?php



    class ControllerAgente{

        private $pdo;

        public function __CONSTRUCT(){
            try {
                $this->pdo = new PDO('mysql:host=localhost;dbname=roberto_realtorscolombia', 'roberto_realtors', 'kvOGmfRGA&3$');
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
                $this->pdo->exec("set names utf8");


            } catch (Exception $e) {
                die($e->getMessage());
            }
        }

        public function obtenerAgentes(){
            try {

            $stm = $this->pdo->prepare("SELECT ID as id, post_title as nombre FROM mubrick_posts WHERE post_type = 'agent'");
            $stm->execute();
            $result = array();

            foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {
                
                $a = new Agente(); 
                $a->__SET('id',$r->id);
                $a->__SET('nombre',$r->nombre);
        
                $result[] = $a;
            }

            return $result;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }


        public function obtenerIdAgente($agente){
            try {
            $id; 
            $stm = $this->pdo->prepare("SELECT ID as id FROM mubrick_posts WHERE post_type = 'agent' and post_title = ?");
            $stm->execute([$agente]);

            foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r) {   
                $id = $r->id;
            }

            return $id;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    }
?>