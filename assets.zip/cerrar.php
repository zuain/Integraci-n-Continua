<?php 

session_start();
session_destroy();
header('Location: https://mubrick.com/reportes/');

?>