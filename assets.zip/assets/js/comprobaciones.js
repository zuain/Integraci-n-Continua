$(document).ready(function(){

function agregarPunto(){

        var ids = ["#canon-arrendamiento", "#precio", "#costo-admin", "#precio-minimo", "#avaluo", "#predial", "#leasing", "#cedula"];
        for (id in ids) {
        $(ids[id]).on({
        "focus": function (event) {
            $(event.target).select();
        },
        "keyup": function (event) {
            $(event.target).val(function (index, value ) {
                return value.replace(/\D/g, "")
                            .replace(/([0-9])([0-9]{3})$/, '$1,$2')
                            .replace(/\B(?=(\d{3})+(?!\d)\.?)/g, ",");
            });
        }});   
        };
}

function verificarCampoNumero(){

        var camposids = ["#habitaciones", "#banios", "#parqueaderos", "#pisos", "#telefono", "#year", "#matricula", "#oficinas_privadas", "#salas_juntas", "#banios-compartidos", "#area_abierta", "#area_oficinas", "#altura_techo", "#fondo", ];

        for (id in camposids) {
        $(camposids[id]).on({
        "focus": function (event) {
            $(event.target).select();
        },
        "keyup": function (event) {
            $(event.target).val(function (index, value ) {
                return value.replace(/\D/g, "");
            });
        }
        });
        };
}


function ocultarCampo(){

    var canon = $('#canon-arrendamiento');
    var venta = $('#precio');

    if($('#contrato').val() == 'for-sale'){
            canon.attr('disabled', 'disabled');
            venta.removeAttr('disabled');
        }else if($('#contrato').val() == 'for-rent'){
            venta.attr('disabled', 'disabled');
            canon.removeAttr('disabled');
        }else if($('#contrato').val() == 'for-rent_and_for-sale'){
            canon.removeAttr('disabled');
            venta.removeAttr('disabled');
        }
       

    $('#contrato').on('change', function(){
        if($(this).val() == 'for-sale'){
            canon.attr('disabled', 'disabled');
            venta.removeAttr('disabled');
        }else if($(this).val() == 'for-rent'){
            venta.attr('disabled', 'disabled');
            canon.removeAttr('disabled');
        }else if($(this).val() == 'for-rent_and_for-sale'){
            canon.removeAttr('disabled');
            venta.removeAttr('disabled');
        }
    });
}

function ocultarCampoAreaBalcon(){

    var balcon = $('#balcon_terraza');
    var area = $('#area-balcones');

    if(balcon.val() == 'No'){
            area.attr('disabled', 'disabled');
    }

    balcon.on('change', function(){
        if($(this).val() == 'No'){
            area.attr('disabled', 'disabled');
        }else{
            area.removeAttr('disabled');
        }
    });
}


function ocultarCampoArea(){

    var area = $('#area-total');

    if($('#tipo').val() == 'Casa'){
        area.removeAttr('disabled');  
    }else if($('#tipo').val() == 'Lote'){
        area.removeAttr('disabled');  
    }else if($('#tipo').val() == 'Finca'){
        area.removeAttr('disabled');  
    }else{
        area.attr('disabled', 'disabled');
    }


    $('#tipo').on('change', function(){
        if($('#tipo').val() == 'Casa'){
            area.removeAttr('disabled');  
        }else if($('#tipo').val() == 'Lote'){
            area.removeAttr('disabled');  
        }else if($('#tipo').val() == 'Finca'){
            area.removeAttr('disabled');  
        }else{
            area.attr('disabled', 'disabled');
        }
    });
}


agregarPunto();
verificarCampoNumero();
ocultarCampo();
ocultarCampoArea();
ocultarCampoAreaBalcon();


     
});