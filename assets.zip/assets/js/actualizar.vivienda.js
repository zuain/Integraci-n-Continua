$(document).ready(function(){

	function actualizar(){
			return $.ajax({
	    // En data puedes utilizar un objeto JSON, un array o un query string
	    data:{
	    "ciudad": $('#ciudad').val(),
		"sector": $('#sector').val(),
		"estrato": $('#estrato').val(),
		"barrio": $('#barrio').val(),
		"tipo_inmueble": $('#tipo').val(),
		"numero_apto": $('#num-apt').val(),
		"tipo_oferta": $('#contrato').val(),
		"precio_lanzamiento": $('#precio').val(),
		"costo_admin": $('#costo-admin').val(),
		"habitaciones": $('#habitaciones').val(),
		"banios": $('#banios').val(),
		"parqueaderos": $('#parqueaderos').val(),
		"area_total": $('#area-total').val(),
		"area_b_t": $('#area-balcones').val(),
		"area_privada": $('#area-privada').val(),
		"area_construida": $('#area-construida').val(),
		"anio_construccion": $('#year').val(),
		"pisos": $('#pisos').val(),
		"penthouse": $('#penthouse').val(),
		"duplex": $('#duplex').val(),
		"amoblado": $('#amoblado').val(),
		"aire_acondicionado": $('#aire').val(),
		"tipo_piso": $('#tipo-piso').val(),
		"cocina_a_c": $('#cocina').val(),
		"tipo_cocina": $('#tipo-cocina').val(),
		"comedor_independiente": $('#comedor').val(),
		"vista_e_i": $('#vista').val(),
		"chimenea": $('#chimenea').val(),
		"cortinas": $('#cortinas').val(),
		"cuarto_servicio": $('#servicio').val(),
		"estudio": $('#estudio').val(),
		"puerta_seguridad": $('#seguridad').val(),
		"deposito": $('#deposito').val(),
		"jacuzzi_sauna": $('#jacuzzi').val(),
		"parqueadero_line_inde": $('#parq').val(),
		"zona_ropas": $('#z-ropa').val(),
		"remodelado": $('#remo').val(),
		"porteria": $('#port').val(),
		"parqueadero_visita": $('#parq-visita').val(),
		"zona_infantil": $('#zona-infan').val(),
		"ascensor": $('#ascensor').val(),
		"piscina": $('#piscina').val(),
		"canchas_depo": $('#canchas').val(),
		"gym": $('#gym').val(),
		"zonas_humedas": $('#z-humedas').val(),
		"terraza_comunal": $('#t-salon').val(),
		"precio_minimo": $('#precio-minimo').val(),
		"avaluo_catastral": $('#avaluo').val(),
		"costo_predial": $('#predial').val(),
		"valor_leasing": $('#leasing').val(),
		"nombre": $('#nombre').val(),
		"cedula": $('#cedula').val(),
		"direccion": $('#direccion-inmueble').val(),
		"matricula_no": $('#matricula').val(),
		"telefono": $('#telefono').val(),
		"email": $('#email').val(),
		"agente": $('#agente').val(),
		"tipo_documento": $('#tipo_documento').val(),
		"calentador": $('#calentador').val(),
		"canon": $('#canon-arrendamiento').val(),
		"balcon_terraza": $('#balcon_terraza').val(),
		"info_adicional": $('#info_adicional').val(),
		"info_adicional_bancaria": $('#info-adicional-bancaria').val(),
		"id": $('input[name=id]').val()
	    },
	    //Cambiar a type: POST si necesario
	    type: "POST",
	    // Formato de datos que se espera en la respuesta
	
	    // URL a la que se enviará la solicitud Ajax
	    url: "https://mubrick.com/reportes/includes/actualizar-vivienda.php",
		}); 
	}

	$('#boton').on('click', function(e){

		

		var a = $("input[name='habitaciones']").val();
		var b = $("input[name='barrio']").val();
		var c = $("input[name='banios']").val();
		var d = $("input[name='parqueaderos']").val();
		var t = $("input[name='area_construida']").val();
		var f = $("input[name='area_privada']").val();
		var g = $("input[name='anio_construccion']").val();
		var h = $("input[name='pisos']").val();
		var i = $("input[name='nombre']").val();
		var j = $("input[name='cedula']").val();
		var k = $("input[name='direccion']").val();
		var l = $("input[name='telefono']").val();
		var m = $("input[name='email']").val();

	if(a != "" && b != "" && c != "" && d != "" && t != "" && f != "" && g != "" && h != "" && i != "" && j != "" && k != "" && l != "" && m != ""){
		//Prevenimos el funcionamiento normal
		e.preventDefault();  

			//Mostramos la animación de carga
			$('#boton i').css('display', 'inline-block');


				
			//Done es ejecutado cuando se recibe la respuesta del servidor. Response es el objeto JSON recibido. 
			actualizar()
			.done(function(response){
				if(response.success){
					$('#boton i').css('display', 'none');
					$('.alert-exito').show("slow");
					setTimeout(function(){
						$('.alert-exito').hide("slow");
					}, 1000);

				}else{
					$('#boton i').css('display', 'none');
					$('.alert-error').show("slow");
					setTimeout(function(){
						$('.alert-error').hide("slow");
					}, 1000);
				}

			})

			.fail(function(jqXHR, textStatus, errorThrown) {
            	$('#boton').html("Error: " + textStatus + " Erorthrow: "+errorThrown);
        	});

	}
		
	});

});