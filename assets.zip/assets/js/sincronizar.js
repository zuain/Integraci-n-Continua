$(document).ready(function(){

	function consignar(id, codigo, tipo){
		return $.ajax({
	    // En data puedes utilizar un objeto JSON, un array o un query string
	    data:{
	    "id": id,
	    "codigo": codigo,
	    "tipo": tipo
	    },
	    //Cambiar a type: POST si necesario
	    type: "POST",
	    // Formato de datos que se espera en la respuesta
	
	    // URL a la que se enviará la solicitud Ajax
	    url: "https://mubrick.com/reportes/includes/sincronizar.php",
		}); 
}


function botonSincronizar(){

	var ids = $('button#sincronizar');
	 
	for (var i = 0; i < ids.length; i++) {
		
		$(ids[i]).on('click', function(e){

			//Prevenimos el funcionamiento normal
			e.preventDefault();  

			var codigo = prompt("Ingrese el código del Inmueble");

			if (codigo != null) {

				var element = $(this);

				//Done es ejecutado cuando se recibe la respuesta del servidor. Response es el objeto JSON recibido. 
				consignar(element.data('id'), codigo, element.data('tipo'))
				.done(function(response){

					if(response.success){

					$('.alert-exito').show("slow");
					setTimeout(function(){
						$('.alert-exito').hide("slow");
					}, 2000);

					element.parents('tr').animate({ backgroundColor: "#003" }, "slow")
	                                         .animate({ opacity: "hide" }, "slow");
	                                         
				}else{
					$('.alert-error').show("slow");
					setTimeout(function(){
						$('.alert-error').hide("slow");
					}, 2000);
				}

				})

				.fail(function(jqXHR, textStatus, errorThrown) {
	            
	        	});

				}
			
		});
 	};
}

botonSincronizar();

});