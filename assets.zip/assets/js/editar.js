$(document).ready(function(){

	function botonEditar(){

	var ids = $('button#editar');
	 
	for (var i = 0; i < ids.length; i++) {
		$(ids[i]).on('click', function(e){
			if($(this).data('tipo') == "vivienda"){
				$('form').attr('action', 'https://mubrick.com/reportes/editar-vivienda.php');
			}else{
				$('form').attr('action', 'https://mubrick.com/reportes/editar-comercial.php');
			}
			$('#id_inmueble').val($(this).data('id'));

			$('form').submit();
		});
	}
}

botonEditar();

});