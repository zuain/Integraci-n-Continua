$(document).ready(function(){

	function consignar(id, tipo){
		return $.ajax({
	    // En data puedes utilizar un objeto JSON, un array o un query string
	    data:{
	    "id": id,
	    "tipo": tipo
	    },
	    //Cambiar a type: POST si necesario
	    type: "POST",
	    // Formato de datos que se espera en la respuesta
	
	    // URL a la que se enviará la solicitud Ajax
	    url: "https://mubrick.com/reportes/includes/obtener-reporte-pdf.php",
		}); 
}


function botonSincronizar(){

	var ids = $('button#ficha');
	 
	for (var i = 0; i < ids.length; i++) {
		
		$(ids[i]).on('click', function(e){

			//Prevenimos el funcionamiento normal
			e.preventDefault();  


				var element = $(this);

				//Done es ejecutado cuando se recibe la respuesta del servidor. Response es el objeto JSON recibido. 
				consignar(element.data('id'), element.data('tipo'))
				.done(function(response){

					if(response.success){
					window.open('includes/ver-ficha.php');  

					}else{
					$('.alert-error').show("slow");
					setTimeout(function(){
						$('.alert-error').hide("slow");
					}, 1000);
				}

				})

				.fail(function(jqXHR, textStatus, errorThrown) {
	            
	        	});

			
		});
 	};
}

botonSincronizar();

});