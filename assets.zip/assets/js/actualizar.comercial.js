$(document).ready(function(){

	function actualizar(){
			return $.ajax({
	    // En data puedes utilizar un objeto JSON, un array o un query string
	    data:{
	    "ciudad": $('#ciudad').val(),
		"sector": $('#sector').val(),
		"estrato": $('#estrato').val(),
		"barrio": $('#barrio').val(),
		"tipo_inmueble": $('#tipo').val(),
		"tipo_oferta": $('#contrato').val(),
		"precio_lanzamiento": $('#precio').val(),
		"costo_admin": $('#costo-admin').val(),
		"oficinas_privadas": $('#oficinas_privadas').val(),
		"salas_juntas": $('#salas_juntas').val(),
		"mobiliario": $('#mobiliario').val(),
		"area_total": $('#area-total').val(),
		"area_b_t": $('#area-balcones').val(),
		"area_privada": $('#area-privada').val(),
		"area_construida": $('#area-construida').val(),
		"anio_construccion": $('#year').val(),
		"pisos": $('#pisos').val(),
		"banios": $('#banios-compartidos').val(),
		"divisiones": $('#divisiones').val(),
		"tipo_piso": $('#tipo-piso').val(),
		"cocina": $('#cocina').val(),
		"iluminacion": $('#iluminacion').val(),
		"red": $('#red').val(),
		"en_edificio": $('#en_edificio').val(),
		"en_centrocomer": $('#en_centrocomer').val(),
		"en_casa": $('#en_casa').val(),
		"en_calle": $('#en_calle').val(),
		"puerta_seguridad": $('#seguridad').val(),
		"deposito": $('#deposito').val(),
		"planta": $('#planta').val(),
		"transporte": $('#transporte').val(),
		"area_abierta": $('#area_abierta').val(),
		"area_oficinas": $('#area_oficinas').val(),
		"porteria": $('#porteria').val(),
		"parqueaderos": $('#parqueaderos').val(),
		"altura_techo": $('#altura_techo').val(),
		"ascensor": $('#ascensor').val(),
		"fondo": $('#fondo').val(),
		"industrial": $('#industrial').val(),
		"p_camiones": $('#p_camiones').val(),
		"entrada_camiones": $('#entrada_camiones').val(),
		"bascula": $('#bascula').val(),
		"nombre": $('#nombre').val(),
		"cedula": $('#cedula').val(),
		"direccion": $('#direccion-inmueble').val(),
		"matricula_no": $('#matricula').val(),
		"telefono": $('#telefono').val(),
		"email": $('#email').val(),
		"agente": $('#agente').val(),
		"tipo_documento": $('#tipo_documento').val(),
		"canon": $('#canon-arrendamiento').val(),
		"balcon_terraza": $('#balcon_terraza').val(),
		"info_adicional": $('#info_adicional').val(),
		"id": $('input[name=id]').val()
	    },
	    //Cambiar a type: POST si necesario
	    type: "POST",
	    // Formato de datos que se espera en la respuesta
	
	    // URL a la que se enviará la solicitud Ajax
	    url: "https://mubrick.com/reportes/includes/actualizar-comercial.php",
		}); 
	}

	$('#boton').on('click', function(e){

		

		var a = $("input[name='parqueaderos']").val();
		var b = $("input[name='barrio']").val();
		var t = $("input[name='area_construida']").val();
		var f = $("input[name='area_privada']").val();
		var g = $("input[name='anio_construccion']").val();
		var h = $("input[name='pisos']").val();
		var i = $("input[name='nombre']").val();
		var j = $("input[name='cedula']").val();
		var k = $("input[name='direccion']").val();
		var l = $("input[name='telefono']").val();
		var m = $("input[name='email']").val();

	if(a != "" && b != "" && t != "" && f != "" && g != "" && h != "" && i != "" && j != "" && k != "" && l != "" && m != ""){

			//Prevenimos el funcionamiento normal
			e.preventDefault();  

			//Mostramos la animación de carga
			$('#boton i').css('display', 'inline-block');

				
			//Done es ejecutado cuando se recibe la respuesta del servidor. Response es el objeto JSON recibido. 
			actualizar()
			.done(function(response){
				if(response.success){
					$('#boton i').css('display', 'none');
					$('.alert-exito').show("slow");
					setTimeout(function(){
						$('.alert-exito').hide("slow");
					}, 1000);

				}else{
					$('#boton i').css('display', 'none');
					$('.alert-exito').show("slow");
					setTimeout(function(){
						$('.alert-exito').hide("slow");
					}, 1000);
				}

			})

			.fail(function(jqXHR, textStatus, errorThrown) {
            	$('#boton').html("Error: " + textStatus + " Erorthrow: "+errorThrown);
        	});

	}
		
	});

});