<?php
session_start();

require_once 'includes/Autoloap.php';

if(!isset($_SESSION['usuario'])){
    header('Location: https://mubrick.com/reportes/');
}

$inmuebles = new ControllerFichaHome();

?>

<!DOCTYPE html>
<html lang="es">
  <head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="https://mubrick.com/wp-content/uploads/2014/11/mubrick.png" type="image/png" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Seleccione una opción</title>

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!-- Estilos -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

<div class="alert alert-info alert-exito" role="alert">Datos actualizados</div>
<div class="alert alert-danger alert-error" role="alert">Error</div>

<nav class="navbar navbar-default">
  <div class="container">
  
      <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse-2" aria-expanded="false">
        <span class="sr-only">Menú</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"><img src="https://mubrick.com/reportes/assets/img/Logo-Mubrick.png" alt="Mubrick"></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse hidden-sm" id="collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
            <img src="https://mubrick.com/reportes/assets/img/user.png" alt="">
            <span class="nombre-usuario">Mubricker<strong>:</strong> <?php echo ucwords($_SESSION['usuario']); ?> <span class="caret" style="color:#fff;"></span></span>
          </a>
          <ul class="dropdown-menu">
            <li><a href="https://mubrick.com/reportes/panel.php">Regresar</a></li>
            <li><a href="https://mubrick.com/reportes/cerrar.php">Salir</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="collapse-2">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="https://mubrick.com/reportes/panel.php" style="color:#fff;">Regresar</a></li>
        <li><a href="https://mubrick.com/reportes/cerrar.php" style="color:#fff;">Salir</a></li>
      </ul>
    </div><!-- / .navbar-collapse -->
  </div><!-- /.container -->
</nav>

    
    <div class="container">
      <div class="col-md-12">
        <div class="panel panel-primary">
        <div class="panel-heading"><p>Listado de inmuebles por sincronizar</p></div>
        <div class="panel-body">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>Propietario</th>
                <th>Inmueble</th>
                <th>Agente</th>
                <th>Gestión</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>

              <?php foreach($inmuebles->obtenerViviendas() as $i): ?>
              <tr class="ocultar">
                <td><?php echo ucfirst($i->__GET('nombre')); ?></td>
                <td>
                  <span class="label label-primary">Vivienda</span>
                </td>
                <td><?php echo ucfirst($i->__GET('agente')); ?></td>
                <td><?php echo $i->__GET('gestion'); ?></td>
                <td class="botones">
                  <button type="button" id="delete" class="btn btn-danger" data-id="<?php echo $i->__GET('id'); ?>" data-tipo="vivienda">Eliminar</button>
                  <button type="button" id="editar" class="btn btn-primary" data-id="<?php echo $i->__GET('id'); ?>" data-tipo="vivienda">Editar</button>
                  <button type="button" id="sincronizar" class="btn btn-success" data-id="<?php echo $i->__GET('id'); ?>" data-tipo="vivienda">Sincronizar</button>
                </td>
              </tr>  
              <?php endforeach; ?>

                <?php foreach($inmuebles->obtenerComercial() as $i): ?>
              <tr class="ocultar">
                <td><?php echo ucfirst($i->__GET('nombre')); ?></td>
                <td>
                  <span class="label label-success">Comercial</span>
                </td>
                <td><?php echo ucfirst($i->__GET('agente')); ?></td>
                <td><?php echo $i->__GET('gestion'); ?></td>
                <td class="botones">
                  <button type="button" id="delete" class="btn btn-danger" data-id="<?php echo $i->__GET('id'); ?>" data-tipo="comercial">Eliminar</button>
                  <button type="button" id="editar" class="btn btn-primary" data-id="<?php echo $i->__GET('id'); ?>" data-tipo="comercial">Editar</button>
                  <button type="button" id="sincronizar" class="btn btn-success" data-id="<?php echo $i->__GET('id'); ?>" data-tipo="comercial">Sincronizar</button>
                </td>
              </tr>  
              <?php endforeach; ?>

            </tbody>
          </table>
        </div>
      </div>
      </div>
    </div><!-- .container -->
    <form action="" method="POST"><input type="hidden" value="" id="id_inmueble" name="id"></form>

    <!--<div class="copyright">
      <p>Camilo Camargo</p>
    </div>-->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Eliminar inmueble -->
    <script src="assets/js/eliminar.inmueble.js"></script>
    <!-- Editar inmueble -->
    <script src="assets/js/editar.js"></script>
    <!-- Sincronizar -->
    <script src="assets/js/sincronizar.js"></script>
  </body>
</html>