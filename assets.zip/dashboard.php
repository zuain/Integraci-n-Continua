<?php
  session_start();

  if(!isset($_SESSION['usuario'])){
    header('Location: https://mubrick.com/reportes/');
  }

  require_once 'includes/Autoloap.php';


  $p = new ControllerPropiedades();
  $date = new DateTime('2000-01-01');


?>

<!DOCTYPE html>
<html lang="es-ES">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="https://mubrick.com/wp-content/uploads/2014/11/mubrick.png" type="image/png" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Dashboard</title>

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Estilos -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="dashboard">

    <nav class="navbar navbar-default">
      <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse-2" aria-expanded="false">
            <span class="sr-only">Menú</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"><img src="https://mubrick.com/reportes/assets/img/Logo-Mubrick.png" alt="Mubrick"></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse hidden-sm" id="collapse-1">
          <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                <img src="https://mubrick.com/reportes/assets/img/user.png" alt="">
                <span class="nombre-usuario">Hola, <?php echo ucwords($_SESSION['usuario']); ?> <span class="caret" style="color:#fff;"></span></span>
              </a>
              <ul class="dropdown-menu">
                <li><a href="https://mubrick.com/reportes/panel.php">Regresar</a></li>
                <li><a href="https://mubrick.com/reportes/includes/reporte_excel.php">Generar reporte</a></li>
                <li><a href="https://mubrick.com/reportes/cerrar.php">Salir</a></li>
              </ul>
            </li>
          </ul>
        </div><!-- /.navbar-collapse -->

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="collapse-2">
          <ul class="nav navbar-nav navbar-right">
           <li><a href="https://mubrick.com/reportes/includes/reporte_excel.php" style="color:#fff;">Generar reporte</a></li>
            <li><a href="https://mubrick.com/reportes/cerrar.php" style="color:#fff;">Salir</a></li>
          </ul>
        </div><!-- / .navbar-collapse -->
      </div><!-- /.container -->
    </nav>


       <div class="container tabla">
          <div class="panel panel-primary">
            <div class="panel-heading"><p>Cantidad de inmuebles activos en el sitio.</p></div>
              <div class="panel-body">
                <table class="table table-striped table-fixed">
                  <thead>
                    <tr>
                      <!--Código, Valor, fecha publicación, Ciudad, Barrio, Agente encargado, Tipo de inmueble (apto, casa, local,etc), gestión (arriendo, venta), estrato, valor administración, número de habitaciones, baños y parqueaderos, Area total y Area sin balcones, Año construcción y piso.-->
                      <th>Código</th> 
                      <th>Valor</th> 
                      <th>Fecha</th> 
                      <th>Ciudad</th> 
                      <th>Barrio</th> 
                      <th>Agente</th> 
                      <th>Tipo</th> 
                      <th>Gestión</th> 
                      <th>Estrato</th> 
                      <th>Valor Admin</th> 
                      <th>Habitaciones</th> 
                      <th>Baños</th> 
                      <th>Parqueaderos</th> 
                      <th>Area Total</th> 
                      <th>Area sin balcones</th> 
                      <th>Año construcción</th> 
                      <th>Piso</th> 
                    </tr>
                  </thead>
                  <tbody>

                  <?php foreach($p->obtenerPropiedades() as $r): ?>
                    <tr>
                      <td><?php echo $r->__GET('codigo'); ?></td>
                      <td><?php echo $r->__GET('precio'); ?></td>
                      <?php  $date = date_create($r->__GET('fecha')); ?>
                      <td><?php echo date_format($date, 'd/m/y');?></td>
                      <td><?php echo $r->__GET('ciudad'); ?></td>
                      <td><?php echo $r->__GET('barrio'); ?></td>
                      <td><?php echo $r->__GET('autor'); ?></td>
                      <td><?php echo $r->__GET('tipo'); ?></td>
                      <td><?php echo $r->__GET('status') == 'for-sale' ? 'Venta' : 'Arriendo'; ?></td>
                      <td><?php echo $r->__GET('estrato'); ?></td>
                      <td><?php echo $r->__GET('admin'); ?></td>
                      <td><?php echo $r->__GET('bath'); ?></td>
                      <td><?php echo $r->__GET('bed'); ?></td>
                      <td><?php echo $r->__GET('park'); ?></td>
                      <td><?php echo $r->__GET('area_total'); ?></td>
                      <td><?php echo $r->__GET('area_privada'); ?></td>
                      <td><?php echo $r->__GET('year'); ?></td>
                      <td><?php echo $r->__GET('pisos'); ?></td>
                    </tr>
                  <?php endforeach; ?>
                  
                  </tbody>
                </table>
              </div>
          </div>       
      
        </div>

    <!-- FOOTER -->
    <!--<footer id="footer">
        <div class="container-fluid">
            <p>Aprende Bootstrap y CodeIgniter &copy; 2015 | Made With <i class="fa fa-heart"></i> by <a href="#">Camilo Camargo</a></p>
        </div>
    </footer> -->
    <!--END FOOTER -->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>