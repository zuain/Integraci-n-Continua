<?php
session_start();

require_once 'includes/Autoloap.php';

if(!isset($_SESSION['usuario'])){
    header('Location: https://mubrick.com/reportes/');
}

#Agentes
$agentes = new ControllerAgente();
#Ciudades
$ciudades = new ControllerCiudad();
#Sectores
$sectores = new ControllerSector();
#ControllerVivienda
$cInmueble = new ControllerComercial();
#Obtengo el inmueble con el ID indicado
$i = $cInmueble->obtenerInmueble($_POST['id']);

function opcionesGenerales($datos, $dUser){

    foreach ($datos as $dato) {
      
      if($dato == $dUser){
        echo "<option value='{$dato}' selected='selected'>{$dato}</option>";
      }else{
        echo "<option value='{$dato}'>{$dato}</option>";
      }
      
    }
}

function opcionesObjetos($datos, $dUser){

    foreach ($datos as $dato) {
      
      if($dato->__GET('nombre') == $dUser){
        echo "<option value='{$dato->__GET('nombre')}' selected='selected'>{$dato->__GET('nombre')}</option>";
      }else{
        echo "<option value='{$dato->__GET('nombre')}'>{$dato->__GET('nombre')}</option>";
      }
      
    }
}

function opcionesCiudades($datos, $dUser){

    foreach ($datos as $dato) {
      
      if($dato->__GET('valor') == $dUser){
        echo "<option value='{$dato->__GET('valor')}' selected='selected'>{$dato->__GET('nombre')}</option>";
      }else{
        echo "<option value='{$dato->__GET('valor')}'>{$dato->__GET('nombre')}</option>";
      }
      
    }
}


function opcionesGestion($datos, $dUser){

    $temp='';

    foreach ($datos as $dato) {
      
      //Mostramos los datos de forma legible
      if($dato == 'for-rent'){
        $temp = 'Arriendo';
      }else if($dato == 'for-sale'){
        $temp = 'Venta';
      }else{
        $temp = 'Arriendo y Venta';
      }

      //Mostramos todos los valores y el establecido en la base de datos
      if($dato == $dUser){
        echo "<option value='{$dato}' selected='selected'>{$temp}</option>";
      }else{
        echo "<option value='{$dato}'>{$temp}</option>";
      }
      
    }
}

function opcionesSectores($dUser, $sectores){

    foreach ($sectores->obtenerSectores()  as $ciudad) {

      if($ciudad->__GET('valor') == $dUser){
        echo "<option value='{$ciudad->__GET('valor')}' selected='selected'>{$ciudad->__GET('nombre')}</option>"; 
      }else{
        echo "<option value='{$ciudad->__GET('valor')}'>{$ciudad->__GET('nombre')}</option>"; 
      }

       foreach ($sectores->obtenerSubSectores($ciudad->__GET('id')) as $sector) {
        if($sector->__GET('valor') == $dUser){
          echo "<option value='{$sector->__GET('valor')}' selected='selected'>-- {$sector->__GET('nombre')}</option>"; 
        }else{
          echo "<option value='{$sector->__GET('valor')}'>-- {$sector->__GET('nombre')}</option>"; 
        }
       }
      
    }
}

?>

<!DOCTYPE html>
<html lang="es">
  <head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="https://mubrick.com/wp-content/uploads/2014/11/mubrick.png" type="image/png" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Editar información</title>

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!-- Estilos -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

<body style="position:relative; padding-top:150px; ">

<div class="alert alert-info alert-exito" role="alert">Datos actualizados</div>
<div class="alert alert-danger alert-error" role="alert">Error</div>


<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
  
      <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse-2" aria-expanded="false">
        <span class="sr-only">Menú</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"><img src="https://mubrick.com/reportes/assets/img/Logo-Mubrick.png" alt="Mubrick"></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse hidden-sm" id="collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
            <img src="https://mubrick.com/reportes/assets/img/user.png" alt="">
            <span class="nombre-usuario">Mubricker<strong>:</strong> <?php echo ucwords($_SESSION['usuario']); ?> <span class="caret" style="color:#fff;"></span></span>
          </a>
          <ul class="dropdown-menu">
            <li><a href="https://mubrick.com/reportes/inmuebles.php">Regresar</a></li>
            <li><a href="https://mubrick.com/reportes/cerrar.php">Salir</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="collapse-2">
      		<ul class="nav navbar-nav navbar-right">
        		<li><a href="https://mubrick.com/reportes/inmuebles.php" style="color:#fff;">Regresar</a></li>
        		<li><a href="https://mubrick.com/reportes/cerrar.php" style="color:#fff;">Salir</a></li>
      		</ul>
    	</div><!-- / .navbar-collapse -->
  	</div><!-- /.container -->
</nav>
    
    <div class="container">
      <div class="col-md-8 col-md-offset-2">

         <h3>INFORMACIÓN GENERAL</h3>
        <p class="sub">Los campos marcados con <span class="obligatorio">*</span> son obligatorios.</p>
        <div class="divisor"></div>
          <form action ="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">

            <!-- id del inmueble -->
            <input type="hidden"  name="id" value="<?php echo $_POST['id']; ?>"> 

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="ciudad">Ciudad <span class="obligatorio">*</span></label>
                  <select class="form-control" id="ciudad" name="ciudad" required>
                    <?php opcionesCiudades($ciudades->obtenerCiudades(), $i->ciudad); ?>
                  </select>
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="sector">Sector <span class="obligatorio">*</span></label>
                  <select class="form-control" id="sector" name="sector" required>
                    <?php opcionesSectores($i->sector, $sectores); ?> 
                  </select>
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="estrato">Estrato <span class="obligatorio">*</span></label>
                  <select class="form-control" id="estrato" name="estrato" required>
                    <?php opcionesGenerales(array("1","2","3","4","5","6"), $i->estrato); ?>
                  </select>
                </div>
              </div><!-- .col -->
            </div><!-- .row -->

            <div class="row">  
              <div class="col-md-4">
                <div class="form-group">
                  <label for="barrio">Barrio <span class="obligatorio">*</span></label>
                   <input type="text" value="<?php echo $i->barrio; ?>" class="form-control" id="barrio" placeholder="Barrio" name="barrio" required>
                </div>
              </div><!-- .col -->
            
              <div class="col-md-4">
                <div class="form-group">
                  <label for="tipo">Tipo de Inmueble <span class="obligatorio">*</span></label>
                  <select class="form-control" id="tipo" name="tipo_inmueble" required>
                    <?php opcionesGenerales(array("bodega","lote","oficina","local-comercial","consultorio"), $i->tipo_inmueble); ?>
                  </select>
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
              <div class="form-group">
                <label for="contrato">Tipo de oferta <span class="obligatorio">*</span></label>
                <select class="form-control" id="contrato" name="tipo_oferta" required>
                  <?php opcionesGestion(array("for-sale","for-rent","for-rent_and_for-sale"), $i->tipo_oferta); ?>
                </select>
              </div>
            </div><!-- .col --> 
            </div><!-- .row -->

            <div class="row">
              <div class="col-md-4">
                <div class="form-group has-feedback">
                <label class="control-label" for="canon-arrendamiento">Canon de arrendamiento</label>
                <div class="input-group">
                  <span class="input-group-addon">$</span>
                  <input type="text" class="form-control" id="canon-arrendamiento" placeholder="Canon de arrendamiento" name="canon" value="<?php echo $i->canon; ?>">
                </div>
            </div>
              </div><!-- .col -->
              <div class="col-md-4">
              <div class="form-group has-feedback">
                <label class="control-label" for="precio">Precio de venta</label>
                <div class="input-group">
                  <span class="input-group-addon">$</span>
                  <input type="text" class="form-control" id="precio" placeholder="Precio de venta" name="precio_lanzamiento" value="<?php echo $i->precio_lanzamiento; ?>">
                </div>
              </div>
              </div><!-- .col -->
              <div class="col-md-4">
              <div class="form-group has-feedback">
                <label class="control-label" for="costo-admin">Costo de administración</label>
                <div class="input-group">
                  <span class="input-group-addon">$</span>
                  <input type="text" class="form-control" id="costo-admin" placeholder="Costo de administración" name="costo_admin" value="<?php echo $i->costo_admin; ?>">
                </div>
              </div>
              </div><!-- .col -->
            </div><!-- .row -->

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="oficinas_privadas">Número de oficinas privadas</label>
                  <input type="text" class="form-control" id="oficinas_privadas" placeholder="Oficinas privadas" name="oficinas_privadas" value="<?php echo $i->oficinas_privadas; ?>">
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                    <label for="salas_juntas">Número de salas de juntas</label>
                    <input type="text" class="form-control" id="salas_juntas" placeholder="Salas de juntas" name="salas_juntas" value="<?php echo $i->salas_juntas; ?>">
                  </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for="mobiliario">Cuenta con mobiliario</label>
                  <select class="form-control" id="mobiliario" name="mobiliario" required>
                     <?php opcionesGenerales(array("No","Si"), $i->mobiliario); ?>
                  </select>
                </div>
              </div><!-- .col -->
            </div><!-- .row -->  

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                    <label for="banios-compartidos">Baños compartidos</label>
                    <input type="text" class="form-control" id="banios-compartidos" placeholder="Baños compartidos" name="banios" value="<?php echo $i->banios; ?>">
                </div>
              </div>
              <div class="col-md-4">
                 <div class="form-group">
                    <label for="parqueaderos">Parqueaderos asignados<span class="obligatorio">*</span></label>
                    <input type="text" class="form-control" id="parqueaderos" placeholder="Parqueaderos asignados" name="parqueaderos" value="<?php echo $i->parqueaderos; ?>" required>
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="area-construida">Área construida (m²)<span class="obligatorio">*</span></label>
                  <input type="text" class="form-control" id="area-construida" placeholder="Área construida" name="area_construida" value="<?php echo $i->area_construida; ?>" required>
                </div>
              </div><!-- .col -->
            </div><!-- .row -->

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="area-privada">Área privada (m²)<span class="obligatorio">*</span></label>
                  <input type="text" class="form-control" id="area-privada" placeholder="Área lote" name="area_privada" value="<?php echo $i->area_privada; ?>" required>
                </div>
              </div><!-- .col -->


              <div class="col-md-4">
                <div class="form-group">
                <label for="balcon_terraza">Balcón - terraza</label>
                  <select class="form-control" id="balcon_terraza" name="balcon_terraza">
                     <?php opcionesGenerales(array("No","Balcón","Terraza","Balcón - terraza"), $i->balcon_terraza); ?>
                  </select>
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="year">Año de construcción <span class="obligatorio">*</span></label>
                  <input value="<?php echo $i->anio_construccion; ?>" type="text" class="form-control" id="year" placeholder="Año" name="anio_construccion">
                </div>
              </div><!-- .col -->
            </div><!-- .row -->  

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="area-total">Área total (m²)</label>
                  <input value="<?php echo $i->area_total; ?>" type="text" class="form-control" id="area-total" placeholder="Área lote" name="area_total">
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="area-balcones">Área balcon - terraza (m²)</label>
                  <input value="<?php echo $i->area_b_t; ?>" type="text" class="form-control" id="area-balcones" placeholder="Área balcón - terraza" name="area_b_t">
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="pisos">Piso <span class="obligatorio">*</span></label>
                  <input value="<?php echo $i->pisos; ?>" type="text" class="form-control" id="pisos" placeholder="En que piso se encuentra" name="pisos" required>
                </div>
              </div><!-- .col -->
            </div><!-- .row -->


          <div class="row">          
              <div class="col-md-4">
                <div class="form-group">
                    <label for="divisiones">Con divisiones</label>
                    <select class="form-control" id="divisiones" name="divisiones">
                      <?php opcionesGenerales(array("No","Si"), $i->divisiones); ?>
                    </select>
                </div>
              </div><!-- .col -->
            
              <div class="col-md-4">
                <div class="form-group">
                  <label for="tipo-piso">Tipo de piso</label>
                  <select class="form-control" id="tipo-piso" name="tipo_piso">
                     <?php opcionesGenerales(array("Laminado","Cerámica","Baldosa","Madera","Alfombra","Cemento pulido","Porcelanato","Mármol","Varios"), $i->tipo_piso); ?>
                  </select>
                </div>
              </div><!-- .col -->

              <div class="col-md-4">
                <div class="form-group">
                  <label for="cocina">Cocineta</label>
                  <select class="form-control" id="cocina" name="cocina">
                    <?php opcionesGenerales(array("No","Si"), $i->cocina); ?>
                  </select>
                </div>
              </div><!-- .col -->

          </div><!-- .row -->  
          <div class="row">   
              
              <div class="col-md-4">
                <div class="form-group">
                  <label for="iluminacion">Iluminación natural</label>
                  <select class="form-control" id="iluminacion" name="iluminacion">
                    <?php opcionesGenerales(array("No","Si"), $i->iluminacion); ?>
                  </select>
                </div>
              </div><!-- .col -->

              <div class="col-md-4">
                <div class="form-group">
                  <label for="red">Red telefónica e Internet</label>
                  <select class="form-control" id="red" name="red">
                    <?php opcionesGenerales(array("No","Si"), $i->red); ?>
                  </select>
                </div>
              </div><!-- .col -->

              <div class="col-md-4">
                <div class="form-group">
                  <label for="deposito">Depósito</label>
                  <select class="form-control" id="deposito" name="deposito">
                      <?php opcionesGenerales(array("No","Si"), $i->deposito); ?>
                  </select>
                </div>
              </div><!-- .col --> 
          </div><!-- .row -->
         
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="seguridad">Puerta de seguridad</label>
                  <select class="form-control" id="seguridad" name="puerta_seguridad">
                      <?php opcionesGenerales(array("No","Si"), $i->puerta_seguridad); ?>
                  </select>
                </div>
              </div><!-- .col -->

              <div class="col-md-4">
                <div class="form-group">
                  <label for="en_edificio">En edificio inteligente</label>
                  <select class="form-control" id="en_edificio" name="en_edificio">
                      <?php opcionesGenerales(array("No","Si"), $i->en_edificio); ?>
                  </select>
                </div>
              </div><!-- .col -->

              <div class="col-md-4">
                <div class="form-group">
                  <label for="en_centrocomer">En centro comercial</label>
                  <select class="form-control" id="en_centrocomer" name="en_centrocomer">
                      <?php opcionesGenerales(array("No","Si"), $i->en_centrocomer); ?>
                  </select>
                </div>
              </div><!-- .col -->
            </div><!-- .row -->
  
            <div class="row">    
              <div class="col-md-4">
                <div class="form-group">
                  <label for="en_casa">En casa</label>
                  <select class="form-control" id="en_casa" name="en_casa">
                      <?php opcionesGenerales(array("No","Si"), $i->en_casa); ?>
                  </select>
                </div>
              </div><!-- .col -->

              <div class="col-md-4">
                <div class="form-group">
                  <label for="en_calle">Sobre la calle</label>
                  <select class="form-control" id="en_calle" name="en_calle">
                      <?php opcionesGenerales(array("No","Si"), $i->en_calle); ?>
                  </select>
                </div>
              </div><!-- .col -->

              <div class="col-md-4">
                <div class="form-group">
                  <label for="porteria">Seguridad/Recepción</label>
                  <select class="form-control" id="porteria" name="porteria">
                     <?php opcionesGenerales(array("No","Vigilancia 24/7","Vigilancia 12/7"), $i->porteria); ?>
                  </select>
                 </div>
              </div><!-- .col -->

            </div><!-- .row -->

            <div class="row">
              
              <div class="col-md-4">
                <div class="form-group">
                  <label for="ascensor">Ascensores</label>
                  <select class="form-control" id="ascensor" name="ascensor">
                      <?php opcionesGenerales(array("No","Si"), $i->ascensor); ?>
                  </select>
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="planta">Planta eléctrica</label>
                  <select class="form-control" id="planta" name="planta">
                      <?php opcionesGenerales(array("No","Si"), $i->planta); ?>
                  </select>
                </div>
              </div><!-- .col -->            
              <div class="col-md-4">
                <div class="form-group">
                  <label for="transporte">Transporte publico</label>
                  <select class="form-control" id="transporte" name="transporte">
                      <?php opcionesGenerales(array("No","Si"), $i->transporte); ?>
                  </select>
                </div>
              </div><!-- .col -->
            </div><!-- .row -->

            <h3>PARA BODEGAS</h3>
            <div class="divisor"></div>

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="area_abierta">Área abierta</label>
                  <input value="<?php echo $i->area_abierta; ?>"  type="text" class="form-control" id="area_abierta" placeholder="Área abierta" name="area_abierta">
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="area_oficinas">Área de oficinas</label>
                  <input value="<?php echo $i->area_oficinas; ?>"  type="text" class="form-control" id="area_oficinas" placeholder="Área de oficinas" name="area_oficinas">
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="altura_techo">Altura techo</label>
                  <input value="<?php echo $i->altura_techo; ?>"  type="text" class="form-control" id="altura_techo" placeholder="Altura techo" name="altura_techo">
                </div>
              </div><!-- .col -->
            </div><!-- .row -->
            
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                    <label for="fondo">Fondo y ancho</label>
                    <input value="<?php echo $i->fondo; ?>"  type="text" class="form-control" id="fondo" placeholder="Fondo y ancho" name="fondo">
                  </div>
                </div><!-- .col -->
              <div class="col-md-4">
                  <div class="form-group">
                    <label for="industrial">En parque industrial</label>
                    <select class="form-control" id="industrial" name="industrial">
                      <?php opcionesGenerales(array("No","Si"), $i->industrial); ?>
                    </select>
                  </div>
                </div><!-- .col -->
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="bascula">Báscula</label>
                    <select class="form-control" id="bascula" name="bascula">
                      <?php opcionesGenerales(array("No","Si"), $i->bascula); ?>
                    </select>
                  </div>
                </div><!-- .col -->
             </div><!-- .row -->
             <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="p_camiones">Parqueadero camiones</label>
                  <select class="form-control" id="p_camiones" name="p_camiones">
                    <?php opcionesGenerales(array("No","Si"), $i->p_camiones); ?>
                  </select>
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="entrada_camiones">Puerta entrada de camiones</label>
                  <select class="form-control" id="entrada_camiones" name="entrada_camiones">
                    <?php opcionesGenerales(array("No","Si"), $i->entrada_camiones); ?>
                  </select>
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="matricula">Número de matricula</span></label>
                  <input value="<?php echo $i->matricula_no; ?>"   type="text" class="form-control" id="matricula" placeholder="Número de matricula" name="matricula_no">
                </div>
              </div><!-- .col -->
            </div><!-- .row -->

            <div class="form-group">
              <label for="info_adicional">Información adicional</label>
              <textarea class="form-control" rows="3" id="info_adicional" name="info_adicional" placeholder="Características sensoriales (Ejem: vista, cálido, iluminado, fresco, espacioso, silencioso, seguro, etc)"><?php echo $i->info_adicional; ?></textarea>
            </div>    
        
            <h3>INFORMACIÓN DEL PROPIETARIO</h3>
            <div class="divisor"></div>
              
            <div class="row">  
              <div class="col-md-4"> 
                <div class="form-group">
                  <label for="nombre">Nombres y apellidos <span class="obligatorio">*</span></label>
                  <input value="<?php echo $i->nombre; ?>"   type="text" class="form-control" id="nombre" placeholder="Nombre completo" name="nombre" required>
                </div>
              </div>   
              <div class="col-md-4">
               <div class="form-group">
                  <label for="tipo_documento">Tipo documento <span class="obligatorio">*</span></label>
                  <select class="form-control" id="tipo_documento" name="tipo_documento">
                    <?php opcionesGenerales(array("Cédula","Cédula de extranjería","Nit","Pasaporte"), $i->tipo_documento); ?>
                  </select>
              </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="cedula">Número de documento <span class="obligatorio">*</span></label>
                  <input value="<?php echo $i->cedula; ?>"   type="text" class="form-control" id="cedula" placeholder="Documento" name="cedula" required>
                </div>
              </div><!-- .col -->
            </div><!-- .row -->

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="direccion-inmueble">Dirección del inmueble <span class="obligatorio">*</span></label>
                  <input value="<?php echo $i->direccion; ?>"   type="text" class="form-control" id="direccion-inmueble" placeholder="Dirección" name="direccion" required> 
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                <div class="form-group">
                  <label for="telefono">Teléfono <span class="obligatorio">*</span></label>
                  <input value="<?php echo $i->telefono; ?>"   type="text" class="form-control" id="telefono" placeholder="Teléfono" name="telefono" required> 
                </div>
              </div><!-- .col -->
              <div class="col-md-4">
                 <div class="form-group">
                  <label for="email">Email <span class="obligatorio">*</span></label>
                  <input value="<?php echo $i->email; ?>" type="email" class="form-control" id="email" placeholder="Email" name="email" required>
                </div>
              </div><!-- .col -->
            </div><!-- .row -->    

            <h3>AGENTE</h3>
            <p class="sub">Solo para Agentes de Mubrick</p>
            <div class="divisor"></div>

            <div class="form-group">
              <label for="agente">Agente</label>
              <select class="form-control" id="agente" name="agente">
                <?php opcionesObjetos($agentes->obtenerAgentes(), $i->agente); ?>
              </select>
            </div>

                <div class="botones">
                  <div class="content-btn">
                    <button name="form-inmueble" class="btn btn-default mi-btn" id="boton">Actualizar <i id="spinner" class="fa fa-spinner fa-pulse fa-1x fa-fw" style="display:none;"></i></button>   
                  </div>
                </div>

        </form>
      </div><!-- /.col -->  
    </div><!-- /.container -->  

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Eliminar inmueble -->
    <script src="assets/js/eliminarInmueble.js"></script>
    <!-- Editar inmueble -->
    <script src="assets/js/editar.js"></script>
    <!-- comprobaciones -->
    <script src="assets/js/comprobaciones.js"></script>
    <!-- actualizar datos -->
    <script src="assets/js/actualizar.comercial.js"></script>
  </body>
</html>