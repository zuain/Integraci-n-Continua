<?php
session_start();

//Abre un PDF existente o lo crea
$temp = fopen('ficha.pdf', 'w+' ); 
//Escribe la información en binarios
fwrite($temp, $_SESSION['ficha']);


header('Content-type: application/pdf');
readfile(dirname(__FILE__) .'/ficha.pdf');
?>