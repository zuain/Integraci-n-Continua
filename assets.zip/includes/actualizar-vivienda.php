<?php 

require_once 'Autoloap.php';

#Agentes
$agente = new ControllerAgente();
#Modelo Vivienda
$i = new Vivienda();
#Consignar el inmueble
$consignar = new ControllerVivienda();

$jsondata = array();

if(isset($_POST['ciudad'])){

  $i->__SET('estado', 'pendiente');
  $i->__SET('ciudad', isset($_POST['ciudad']) ? $_POST['ciudad'] : '');
  $i->__SET('sector', isset($_POST['sector']) ? $_POST['sector'] : '');
  $i->__SET('estrato', isset($_POST['estrato']) ? $_POST['estrato'] : '');
  $i->__SET('barrio', isset($_POST['barrio']) ? $_POST['barrio'] : 'barrio');
  $i->__SET('tipo_inmueble', isset($_POST['tipo_inmueble']) ? $_POST['tipo_inmueble'] : '');
  $i->__SET('numero_apto', isset($_POST['numero_apto']) ? $_POST['numero_apto'] : '');
  $i->__SET('tipo_oferta', isset($_POST['tipo_oferta']) ? $_POST['tipo_oferta'] : '');
  $i->__SET('precio_lanzamiento', isset($_POST['precio_lanzamiento']) ? $_POST['precio_lanzamiento'] : '');
  $i->__SET('costo_admin', isset($_POST['costo_admin']) ? $_POST['costo_admin'] : '');
  $i->__SET('habitaciones', isset($_POST['habitaciones']) ? $_POST['habitaciones'] : '');
  $i->__SET('banios', isset($_POST['banios']) ? $_POST['banios'] : '');
  $i->__SET('parqueaderos', isset($_POST['parqueaderos']) ? $_POST['parqueaderos'] : '');
  $i->__SET('area_total', isset($_POST['area_total']) ? $_POST['area_total'] : '');
  $i->__SET('area_privada', isset($_POST['area_privada']) ? $_POST['area_privada'] : '');
  $i->__SET('area_construida', isset($_POST['area_construida']) ? $_POST['area_construida'] : '');
  $i->__SET('area_b_t', isset($_POST['area_b_t']) ? $_POST['area_b_t'] : '');
  $i->__SET('anio_construccion', isset($_POST['anio_construccion']) ? $_POST['anio_construccion'] : '');
  $i->__SET('pisos', isset($_POST['pisos']) ? $_POST['pisos'] : '');
  $i->__SET('penthouse', isset($_POST['penthouse']) ? $_POST['penthouse'] : '');
  $i->__SET('duplex', isset( $_POST['duplex']) ?  $_POST['duplex'] : '');
  $i->__SET('amoblado', isset($_POST['amoblado']) ? $_POST['amoblado'] : '');
  $i->__SET('aire_acondicionado', isset($_POST['aire_acondicionado']) ? $_POST['aire_acondicionado'] : '');
  $i->__SET('tipo_piso', isset($_POST['tipo_piso']) ? $_POST['tipo_piso'] : '');
  $i->__SET('cocina_a_c', isset($_POST['cocina_a_c']) ? $_POST['cocina_a_c'] : '');
  $i->__SET('tipo_cocina', isset($_POST['tipo_cocina']) ? $_POST['tipo_cocina'] : '');
  $i->__SET('comedor_independiente', isset($_POST['comedor_independiente']) ? $_POST['comedor_independiente'] : '');
  $i->__SET('vista_e_i', isset($_POST['vista_e_i']) ? $_POST['vista_e_i'] : '');
  $i->__SET('chimenea', isset($_POST['chimenea']) ? $_POST['chimenea'] : '');
  $i->__SET('cortinas', isset($_POST['cortinas']) ? $_POST['cortinas'] : '');
  $i->__SET('cuarto_servicio', isset($_POST['cuarto_servicio']) ? $_POST['cuarto_servicio'] : '');
  $i->__SET('estudio', isset($_POST['estudio']) ? $_POST['estudio'] : '');
  $i->__SET('puerta_seguridad', isset($_POST['puerta_seguridad']) ? $_POST['puerta_seguridad'] : '');
  $i->__SET('deposito', isset($_POST['deposito']) ? $_POST['deposito'] : '');
  $i->__SET('jacuzzi_sauna', isset($_POST['jacuzzi_sauna']) ? $_POST['jacuzzi_sauna'] : '');
  $i->__SET('parqueadero_line_inde', isset($_POST['parqueadero_line_inde']) ? $_POST['parqueadero_line_inde'] : '');
  $i->__SET('zona_ropas', isset($_POST['zona_ropas']) ? $_POST['zona_ropas'] : '');
  $i->__SET('remodelado', isset($_POST['remodelado']) ? $_POST['remodelado'] : '');
  $i->__SET('porteria', isset($_POST['porteria']) ? $_POST['porteria'] : '');
  $i->__SET('parqueadero_visita', isset($_POST['parqueadero_visita']) ? $_POST['parqueadero_visita'] : '');  
  $i->__SET('zona_infantil', isset($_POST['zona_infantil']) ? $_POST['zona_infantil'] : '');
  $i->__SET('ascensor', isset($_POST['ascensor']) ? $_POST['ascensor'] : '');
  $i->__SET('piscina', isset($_POST['piscina']) ? $_POST['piscina'] : '');
  $i->__SET('canchas_depo', isset($_POST['canchas_depo']) ? $_POST['canchas_depo'] : '');
  $i->__SET('gym', isset($_POST['gym']) ? $_POST['gym'] : '');
  $i->__SET('zonas_humedas', isset($_POST['zonas_humedas']) ? $_POST['zonas_humedas'] : '');
  $i->__SET('terraza_comunal', isset($_POST['terraza_comunal']) ? $_POST['terraza_comunal'] : '');
  $i->__SET('precio_minimo', isset($_POST['precio_minimo']) ? $_POST['precio_minimo'] : '');
  $i->__SET('avaluo_catastral', isset($_POST['avaluo_catastral']) ? $_POST['avaluo_catastral'] : '');
  $i->__SET('costo_predial', isset($_POST['costo_predial']) ? $_POST['costo_predial'] : '');
  $i->__SET('valor_leasing', isset($_POST['valor_leasing']) ? $_POST['valor_leasing'] : '');
  $i->__SET('nombre', isset($_POST['nombre']) ? $_POST['nombre'] : '');
  $i->__SET('cedula', isset($_POST['cedula']) ? $_POST['cedula'] : '');
  $i->__SET('direccion', isset($_POST['direccion']) ? $_POST['direccion'] : '');
  $i->__SET('matricula_no', isset($_POST['matricula_no']) ? $_POST['matricula_no'] : '');
  $i->__SET('telefono', isset($_POST['telefono']) ? $_POST['telefono'] : '');
  $i->__SET('email', isset($_POST['email']) ? $_POST['email'] : '');
  $i->__SET('agente', isset($_POST['agente']) ? $_POST['agente'] : '');
  $i->__SET('id_agente', ($_POST['agente']) ? $agente->obtenerIdAgente($_POST['agente']) : '');
  $i->__SET('tipo_documento', isset($_POST['tipo_documento']) ? $_POST['tipo_documento'] : '');
  $i->__SET('calentador', isset($_POST['calentador']) ? $_POST['calentador'] : '');
  $i->__SET('canon', isset($_POST['canon']) ? $_POST['canon'] : '');
  $i->__SET('balcon_terraza', isset($_POST['balcon_terraza']) ? $_POST['balcon_terraza'] : '');
  $i->__SET('info_adicional', isset( $_POST['info_adicional']) ?  $_POST['info_adicional'] : '');
  $i->__SET('info_adicional_bancaria', isset( $_POST['info_adicional_bancaria']) ?  $_POST['info_adicional_bancaria'] : '');

    if($consignar->actualizarInmueble($i, $_POST['id'])){
      $jsondata['success'] = true;
    }else{
      $jsondata['success'] = false;  
    }

}else{
    $jsondata['success'] = false;  
}
 

  header('Content-type: application/json; charset=utf-8');
  echo json_encode($jsondata, JSON_FORCE_OBJECT);
  
?> 