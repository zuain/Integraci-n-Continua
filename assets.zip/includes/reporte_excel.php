<?php

require_once 'reportes/PHPReport.php';
require_once 'Autoloap.php';


$p = new ControllerPropiedades();
$pTotal = array();


foreach ($p->obtenerPropiedades() as $r) {
	$date = date_create($r->__GET('fecha'));

	$pTemp = array(
		$r->__GET('codigo'),
		$r->__GET('precio'),
		date_format($date, 'd/m/y'),
		$r->__GET('ciudad'),
		$r->__GET('barrio'),
		$r->__GET('autor'),
		$r->__GET('tipo'),
		$r->__GET('status') == 'for-sale' ? 'Venta' : 'Arriendo',
		$r->__GET('estrato'),
		$r->__GET('admin'),
		$r->__GET('bath'),
		$r->__GET('bed'),
		$r->__GET('park'),
		$r->__GET('area_total'),
		$r->__GET('area_privada'),
		$r->__GET('year'),
		$r->__GET('pisos')
		);

	$pTotal[] = $pTemp;

}

$R=new PHPReport();
$R->load(array(
            'id'=>'propiedad',
			'header'=>array(
					'Código','Valor','Fecha', 'Ciudad', 'Barrio', 'Agente', 'Tipo', 'Gestión', 'Estrato', 'Valor Admin', 'Habitaciones', 'Baños', 'Parqueaderos', 'Area Total', 'Area sin balcones', 'Año construcción', 'Piso'
				),
            'data'=>$pTotal,
            'config'=>array(
					0=>array('width'=>120,'align'=>'left'),
					1=>array('width'=>120,'align'=>'left'),
					2=>array('width'=>120,'align'=>'left'),
					3=>array('width'=>120,'align'=>'left'),
					4=>array('width'=>250,'align'=>'left'),
					5=>array('width'=>120,'align'=>'left'),
					6=>array('width'=>120,'align'=>'left'),
					7=>array('width'=>120,'align'=>'left'),
					8=>array('width'=>120,'align'=>'left'),
					9=>array('width'=>120,'align'=>'left'),
					10=>array('width'=>120,'align'=>'left'),
					11=>array('width'=>120,'align'=>'left'),
					12=>array('width'=>120,'align'=>'left'),
					13=>array('width'=>120,'align'=>'left'),
					14=>array('width'=>120,'align'=>'left'),
					15=>array('width'=>120,'align'=>'left'),
					16=>array('width'=>120,'align'=>'left')
				)
            )
        );

$R->render('excel');

?>

