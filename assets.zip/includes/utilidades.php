<?php

	class Utilidades{

		public function opcionesGenerales($datos, $dUser){

		    foreach ($datos as $dato) {
		      if($dato == $dUser){
		        echo "<option value='{$dato}' selected='selected'>{$dato}</option>";
		      }else{
		        echo "<option value='{$dato}'>{$dato}</option>";
		      }
		      
		    }
		}
}

 ?>