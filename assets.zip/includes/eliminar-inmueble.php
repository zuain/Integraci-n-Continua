<?php 

require_once 'Autoloap.php';

$ficha = new ControllerFichaHome();

$jsondata = array();

if(isset($_POST['id'])){

    if($ficha->eliminar($_POST['id'], $_POST['tipo'])){
      $jsondata['success'] = true;
    }else{
      $jsondata['success'] = false;  
    }
}else{
    $jsondata['success'] = false;  
}
 

  header('Content-type: application/json; charset=utf-8');
  echo json_encode($jsondata, JSON_FORCE_OBJECT);
  
?> 