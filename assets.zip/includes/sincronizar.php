<?php 
error_reporting(E_ALL);
require_once 'Autoloap.php';
#Controller Comercial
$inmueble = new ControllerInmuebleGeneral();

try{

	$inmueble->agregarCodigo($_POST['id'], $_POST['tipo'], $_POST['codigo']);
	$inmueble->insertarPost($_POST['codigo']);
	$inmueble->insertarMetaDatos($inmueble->obtenerInmueble($_POST['id'], $_POST['tipo']), $inmueble->obtenerId());
	$inmueble->cambiarEstado($_POST['id'], $_POST['tipo']);

	$jsondata['success'] = true;

}catch(Exception $e){

	$jsondata['success'] = false;  
	die($e->getMessage());

}



  header('Content-type: application/json; charset=utf-8');
  echo json_encode($jsondata, JSON_FORCE_OBJECT);
  
?> 