<?php

require('fpdf.php');



class FichaComercial extends FPDF {

protected $col = 0; // Columna actual
protected $y0;      // Ordenada de comienzo de la columna
private $i = null;


   function __construct($i) {
       parent::__construct();
       $this->i = $i;
   }

function Header()
{
    // Logo
    $this->Image('https://mubrick.com/wp-content/uploads/2017/03/Logo-Mubrick.png',10,8,33);
    // Arial bold 15
    $this->setFont('Arial','B',12);
    // Título
    $this->Cell(0,10,utf8_decode('Ficha Técnica - Código: ' . $this->i->__GET('codigo')),0,0,'C');
    // Salto de línea
    $this->Ln(20);
}

function Footer()
{
    // Pie de página
    $this->setY(-15);
    $this->setFont('Arial','I',8);
    $this->setTextColor(128);
    $this->Cell(0,10,'Mubrick',0,0,'C');
}

function setCol($col)
{
    // Establecer la posición de una columna dada
    $this->col = $col;
    $x = 10+$col*90;
    $this->setLeftMargin($x);
    $this->setX($x);
}

function AcceptPageBreak()
{
    // Método que acepta o no el salto automático de página
    if($this->col<1)
    {
        // Ir a la siguiente columna
        $this->setCol($this->col+1);
        // Establecer la ordenada al principio
        $this->setY($this->y0);
        // Seguir en esta página
        return false;
    }
    else
    {
        // Volver a la primera columna
        $this->setCol(0);
        // Salto de página
        return true;
    }
}

function Titulo($title)
{
    
    $this->setFillColor(200,220,255);
    $this->Ln(2);
    $this->Cell(80,5,utf8_decode($title),0,5,'L',true);
    $this->Ln(2);
    // Guardar ordenada
    $this->y0 = $this->GetY();
     
}

function ChapterBody()
{
    // Fuente
    $this->setFont('Arial','',12);
    $this->setFillColor(200,220,255);
    $this->Titulo('INFORMACIÓN GENERAL');
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('ciudad'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('sector'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('estrato'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('barrio'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('tipo_inmueble'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('tipo_oferta'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('precio_lanzamiento'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('canon'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('costo_admin'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('oficinas_privadas'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('salas_juntas'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('mobiliario'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('banios'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('parqueaderos'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('area_privada'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('area_construida'))),0,1);        
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('area_total'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('balcon_terraza'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('area_b_t'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('anio_construccion'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('pisos'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('divisiones'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('cocina'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('iluminacion'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('red'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('tipo_piso'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('en_edificio'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('en_centrocomer'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('en_casa'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('en_calle'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('planta'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('transporte'))),0,1);
              $this->Ln(2);
              $this->Cell(80,7,utf8_decode('PARA BODEGAS'),0,1,'L', true);
              $this->Ln(2);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('area_abierta'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('area_oficinas'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('puerta_seguridad'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('deposito'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('altura_techo'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('fondo'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('industrial'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('p_camiones'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('porteria'))),0,1);  
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('entrada_camiones'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('bascula'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('ascensor'))),0,1);  
              $this->Ln(2);
              $this->Cell(80,7,utf8_decode('INFORMACIÓN DEL PROPIETARIO'),0,1,'L', true);
              $this->Ln(2);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('nombre'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('tipo_documento'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('cedula'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('matricula_no'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('direccion'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('telefono'))),0,1);
              $this->Cell(80,7,utf8_decode(ucwords($this->i->__GET('email'))),0,1);
              $this->Ln(2);
              $this->Cell(80,5,utf8_decode('INFORMACIÓN ADICIONAL'),0,5,'L', true);
              $this->Ln(2);
              $this->MultiCell(80,7,utf8_decode($this->i->__GET('info_adicional')),0,1);
              

    // Volver a la primera columna
    $this->SetCol(0);
}

function PrintChapter()
{
    // Añadir capítulo
    $this->AddPage();
    $this->ChapterBody();
}


}

?>