<?php
	session_start();

	require_once dirname(__FILE__) . '/Autoloap.php';

	$i = null;
	$pdf = null;
	$response = array();

	try {

		if($_POST['tipo'] == 'vivienda'){

			require_once 'reportes-pdf/FichaVivienda.php';
			$i = new ControllerVivienda();
			$pdf = new FichaVivienda($i->obtenerInmuebleReporte($_POST['id']));

		}else{

			require_once 'reportes-pdf/FichaComercial.php';
			$i = new ControllerComercial();
			$pdf = new FichaComercial( $i->obtenerInmuebleReporte($_POST['id']) );

		}
		
		$pdf->PrintChapter($i->obtenerInmuebleReporte($_POST['id']));
		$_SESSION['ficha'] = $pdf->Output('S');
		$response['success'] = true;


		
	} catch (Exception $e) {
		$response['success'] = false;
	}
	
	  header('Content-type: application/json; charset=utf-8');
  	  echo json_encode($response, JSON_FORCE_OBJECT);

?>