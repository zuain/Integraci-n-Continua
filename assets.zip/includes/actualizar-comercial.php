<?php 

require_once 'Autoloap.php';

#Agentes
$agente = new ControllerAgente();
#Modelo Comercial
$i = new Comercial();
#Controller Comercial
$consignar = new ControllerComercial();

$jsondata = array();

if(isset($_POST['ciudad'])){

  $i->__SET('estado', 'pendiente');
  $i->__SET('ciudad', isset($_POST['ciudad']) ? $_POST['ciudad'] : '');
  $i->__SET('sector', isset($_POST['sector']) ? $_POST['sector'] : '');
  $i->__SET('estrato', isset($_POST['estrato']) ? $_POST['estrato'] : '');
  $i->__SET('barrio', isset($_POST['barrio']) ? $_POST['barrio'] : '');
  $i->__SET('tipo_inmueble', isset($_POST['tipo_inmueble']) ? $_POST['tipo_inmueble'] : '');
  $i->__SET('tipo_oferta', isset($_POST['tipo_oferta']) ? $_POST['tipo_oferta'] : '');
  $i->__SET('precio_lanzamiento', isset($_POST['precio_lanzamiento']) ? $_POST['precio_lanzamiento'] : '');
  $i->__SET('costo_admin', isset($_POST['costo_admin']) ? $_POST['costo_admin'] : '');
  $i->__SET('oficinas_privadas', isset($_POST['oficinas_privadas']) ? $_POST['oficinas_privadas'] : '');
  $i->__SET('salas_juntas', isset($_POST['salas_juntas']) ? $_POST['salas_juntas'] : '');
  $i->__SET('mobiliario', isset($_POST['mobiliario']) ? $_POST['mobiliario'] : '');
  $i->__SET('banios', isset($_POST['banios_compartidos']) ? $_POST['banios_compartidos'] : '');
  $i->__SET('parqueaderos', isset($_POST['parqueaderos']) ? $_POST['parqueaderos'] : '');
  $i->__SET('area_total', isset($_POST['area_total']) ? $_POST['area_total'] : '');
  $i->__SET('area_privada', isset($_POST['area_privada']) ? $_POST['area_privada'] : '');
  $i->__SET('area_construida', isset($_POST['area_construida']) ? $_POST['area_construida'] : '');
  $i->__SET('area_b_t', isset($_POST['area_b_t']) ? $_POST['area_b_t'] : '');
  $i->__SET('anio_construccion', isset($_POST['anio_construccion']) ? $_POST['anio_construccion'] : '');
  $i->__SET('pisos', isset($_POST['pisos']) ? $_POST['pisos'] : '');
  $i->__SET('divisiones', isset($_POST['divisiones']) ? $_POST['divisiones'] : '');
  $i->__SET('tipo_piso', isset($_POST['tipo_piso']) ? $_POST['tipo_piso'] : '');
  $i->__SET('cocina', isset($_POST['cocina']) ? $_POST['cocina'] : '');
  $i->__SET('iluminacion', isset($_POST['iluminacion']) ? $_POST['iluminacion'] : '');
  $i->__SET('red', isset($_POST['red']) ? $_POST['red'] : '');
  $i->__SET('cortinas', isset($_POST['cortinas']) ? $_POST['cortinas'] : '');
  $i->__SET('deposito', isset($_POST['deposito']) ? $_POST['deposito'] : '');
  $i->__SET('puerta_seguridad', isset($_POST['puerta_seguridad']) ? $_POST['puerta_seguridad'] : '');
  $i->__SET('en_edificio', isset($_POST['en_edificio']) ? $_POST['en_edificio'] : '');
  $i->__SET('en_centrocomer', isset($_POST['en_centrocomer']) ? $_POST['en_centrocomer'] : '');
  $i->__SET('en_casa', isset($_POST['en_casa']) ? $_POST['en_casa'] : '');
  $i->__SET('en_calle', isset($_POST['en_calle']) ? $_POST['en_calle'] : '');
  $i->__SET('porteria', isset($_POST['porteria']) ? $_POST['porteria'] : '');
  $i->__SET('ascensor', isset($_POST['ascensor']) ? $_POST['ascensor'] : '');
  $i->__SET('planta', isset($_POST['planta']) ? $_POST['planta'] : '');
  $i->__SET('transporte', isset($_POST['transporte']) ? $_POST['transporte'] : '');
  $i->__SET('area_abierta', isset($_POST['area_abierta']) ? $_POST['area_abierta'] : '');
  $i->__SET('area_oficinas', isset($_POST['area_oficinas']) ? $_POST['area_oficinas'] : '');
  $i->__SET('altura_techo', isset($_POST['altura_techo']) ? $_POST['altura_techo'] : '');
  $i->__SET('industrial', isset($_POST['industrial']) ? $_POST['industrial'] : '');
  $i->__SET('bascula', isset($_POST['bascula']) ? $_POST['bascula'] : '');
  $i->__SET('p_camiones', isset($_POST['p_camiones']) ? $_POST['p_camiones'] : '');
  $i->__SET('entrada_camiones', isset($_POST['entrada_camiones']) ? $_POST['entrada_camiones'] : '');
  $i->__SET('fondo', isset($_POST['fondo']) ? $_POST['fondo'] : '');
  $i->__SET('nombre', isset($_POST['nombre']) ? $_POST['nombre'] : '');
  $i->__SET('cedula', isset($_POST['cedula']) ? $_POST['cedula'] : '');
  $i->__SET('direccion', isset($_POST['direccion']) ? $_POST['direccion'] : '');
  $i->__SET('matricula_no', isset($_POST['matricula_no']) ? $_POST['matricula_no'] : '');
  $i->__SET('telefono', isset($_POST['telefono']) ? $_POST['telefono'] : '');
  $i->__SET('email', isset($_POST['email']) ? $_POST['email'] : '');
  $i->__SET('agente', isset($_POST['agente']) ? $_POST['agente'] : '');
  $i->__SET('id_agente', ($_POST['agente']) ? $agente->obtenerIdAgente($_POST['agente']) : '');
  $i->__SET('tipo_documento', isset($_POST['tipo_documento']) ? $_POST['tipo_documento'] : '');
  $i->__SET('canon', isset($_POST['canon']) ? $_POST['canon'] : '');
  $i->__SET('balcon_terraza', isset($_POST['balcon_terraza']) ? $_POST['balcon_terraza'] : '');
  $i->__SET('info_adicional', isset( $_POST['info_adicional']) ?  $_POST['info_adicional'] : '');

    if($consignar->actualizarInmueble($i, $_POST['id'])){
      $jsondata['success'] = true;
    }else{
      $jsondata['success'] = false;  
    }

}else{
    $jsondata['success'] = false;  
}
 

  header('Content-type: application/json; charset=utf-8');
  echo json_encode($jsondata, JSON_FORCE_OBJECT);
  
?> 