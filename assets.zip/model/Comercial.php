<?php 
	
	class Comercial{
		
		private $codigo;
		private $estado; 
		private $ciudad;
		private $sector;
		private $estrato;
		private $barrio;
		private $tipo_inmueble;
		private $tipo_oferta;
		private $precio_lanzamiento;
		private $costo_admin;
		private $oficinas_privadas;
		private $salas_juntas;
		private $mobiliario;
		private $area_total;
		private $area_b_t;
		private $area_privada;
		private $area_construida;
		private $anio_construccion;
		private $pisos;
		private $banios;
		private $divisiones;
		private $tipo_piso;
		private $cocina;
		private $iluminacion;
		private $red;
		private $en_edificio;
		private $en_centrocomer;
		private $en_casa;
		private $en_calle;
		private $puerta_seguridad;
		private $deposito;
		private $planta;
		private $transporte;
		private $area_abierta;
		private $area_oficinas;
		private $porteria;
		private $parqueaderos;
		private $altura_techo;
		private $ascensor;
		private $fondo;
		private $industrial;
		private $p_camiones;
		private $entrada_camiones;
		private $bascula;
		private $nombre;
		private $cedula;
		private $direccion;
		private $matricula_no;
		private $telefono;
		private $email;
		private $agente;
		private $id_agente;
		private $tipo_documento;
		private $canon;
		private $balcon_terraza;
		private $info_adicional;
	

	public function __GET($k){
		 return $this->$k; 
	}
    	
    public function __SET($k, $v){
    	 return $this->$k = $v; 
    }

}

?>