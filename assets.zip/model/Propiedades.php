<?php

	class Propiedades{
		private $fecha;
		private $autor;
		private $codigo;
		private $precio;
		private $ciudad;
		private $barrio;
		private $tipo;
		private $status;
		private $estrato;
		private $admin;
		private $bed;
		private $bath;
		private $park;
		private $area_total;
		private $area_privada;
		private $year;
		private $pisos;

		public function __GET($k){
		 return $this->$k; 
		}
    	
    	public function __SET($k, $v){
    	 return $this->$k = $v; 
    	}

	}


?>