<?php
	
	Class FichaHome{
		private $id;
		private $nombre;
		private $agente;
		private $gestion;
		private $codigo;

		public function __GET($k){
		 return $this->$k; 
		}
    	
    	public function __SET($k, $v){
    	 return $this->$k = $v; 
    	}
	}

?>