<?php

	class InmuebleGeneral{
	

		private $shandora_listing_codigo;
		private $shandora_listing_ciudad;
		private $shandora_listing_sector;
		private $shandora_listing_barrio;
		private $shandora_listing_estrato;
		private $shandora_listing_tipo_inmueble;
		private $shandora_listing_status;
		private $shandora_listing_price;
	    private $shandora_listing_admon;
		private $shandora_listing_bed;
		private $shandora_listing_bath;
		private $shandora_listing_garage;
		private $shandora_listing_area_construida;
		private $shandora_listing_area_privada;
		private $shandora_listing_area_b_t;
		private $shandora_listing_area_cons_org;
		private $shandora_listing_floor;
		private $shandora_listing_pent_house;
		private $shandora_listing_aire_acondicionado;
		private $shandora_listing_duplex;
		private $shandora_listing_amoblado;
		private $shandora_listing_baldosa;
		private $shandora_listing_tipo_cocina;
		private $shandora_listing_tipo_cocina_1;
		private $shandora_listing_comedor_independiente;
		private $shandora_listing_exterior_interior;
		private $shandora_listing_chimenea;
		private $shandora_listing_cortinas;
		private $shandora_listing_cuarto_servicio;
		private $shandora_listing_estudio;
		private $shandora_listing_puerta_seguridad;
		private $shandora_listing_deposito;
		private $shandora_listing_jacuzzi;
		private $shandora_listing_tipo_garage;
		private $shandora_listing_zona_lavanderia;
		private $shandora_listing_porteria;
		private $shandora_listing_parqueadero_visitantes;
		private $shandora_listing_zona_infantil;
		private $shandora_listing_ascensor;
		private $shandora_listing_piscina;
		private $shandora_listing_canchas_deportivas;
		private $shandora_listing_gimnasio;
		private $shandora_listing_zonas_humedas;
		private $shandora_listing_jardines;
		private $shandora_listing_terraza;
		private $shandora_listing_trans_publico_cercano;
		private $shandora_listing_precio_negociable;
		private $shandora_listing_agentpointed;
		private $shandora_listing_yearbuild;

		public function __GET($k){
		
		   return $this->$k; 
		
		 
		}
    	
    	public function __SET($k, $v){
    	 return $this->$k = $v; 
    	}
    	
	}
?>