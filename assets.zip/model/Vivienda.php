<?php 
	
	class Vivienda{
		
		private $codigo;
		private $estado; 
		private $ciudad;
		private $sector;
		private $estrato;
		private $barrio;
		private $tipo_inmueble;
		private $numero_apto;
		private $tipo_oferta;
		private $precio_lanzamiento;
		private $costo_admin;
		private $habitaciones;
		private $banios;
		private $parqueaderos;
		private $area_total;
		private $area_b_t;
		private $area_privada;
		private $area_construida;
		private $anio_construccion;
		private $pisos;
		private $penthouse;
		private $duplex;
		private $amoblado;
		private $aire_acondicionado;
		private $tipo_piso;
		private $cocina_a_c;
		private $tipo_cocina;
		private $comedor_independiente;
		private $vista_e_i;
		private $chimenea;
		private $cortinas;
		private $cuarto_servicio;
		private $estudio;
		private $puerta_seguridad;
		private $deposito;
		private $jacuzzi_sauna;
		private $parqueadero_line_inde;
		private $zona_ropas;
		private $remodelado;
		private $porteria;
		private $parqueadero_visita;
		private $zona_infantil;
		private $ascensor;
		private $piscina;
		private $canchas_depo;
		private $gym;
		private $zonas_humedas;
		private $terraza_comunal;
		private $precio_minimo;
		private $avaluo_catastral;
		private $costo_predial;
		private $valor_leasing;
		private $nombre;
		private $cedula;
		private $direccion;
		private $matricula_no;
		private $telefono;
		private $email;
		private $agente;
		private $id_agente;
		private $tipo_documento;
		private $calentador;
		private $canon;
		private $balcon_terraza;
		private $info_adicional;
		private $info_adicional_bancaria;
	

	public function __GET($k){
		 return $this->$k; 
	}
    	
    public function __SET($k, $v){
    	 return $this->$k = $v; 
    }

}

?>